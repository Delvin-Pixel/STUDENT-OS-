import { describe, expect, it } from "vitest";
import fs from "node:fs";
import path from "node:path";

describe("workspace conflict resolution contract", () => {
  it("exposes explicit cloud, local, and merge resolution paths", () => {
    const source = fs.readFileSync(path.resolve(__dirname, "StoreContext.tsx"), "utf8");
    expect(source).toContain('resolveWorkspaceConflict: (resolution: "cloud" | "local" | "merge")');
    expect(source).toContain('resolution === "cloud"');
    expect(source).toContain('resolution === "local"');
    expect(source).toContain('mergeWorkspaceStates(remoteState, localState)');
  });
});
