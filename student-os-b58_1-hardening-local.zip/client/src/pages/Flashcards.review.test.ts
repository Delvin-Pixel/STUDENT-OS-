import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { describe, expect, it } from "vitest";

const source = readFileSync(fileURLToPath(new URL("./Flashcards.tsx", import.meta.url)), "utf8");

describe("Flashcards review runner", () => {
  it("claims the current card before marking it and advancing the review", () => {
    expect(source).toContain('const reviewedCardRef = useRef<string | null>(null);');
    expect(source).toContain('if (reviewedCardRef.current === card.id) return;');
    expect(source).toContain('reviewedCardRef.current = card.id;');
    expect(source).toContain('onMark(card.id, grade, card);');
  });

  it("makes card faces keyboard-focusable and operable with Enter or Space", () => {
    expect(source).toContain('tabIndex={0}');
    expect(source).toContain('onKeyDown={handleFlipKeyDown}');
    expect(source).toContain('if (event.key !== "Enter" && event.key !== " ") return;');
    expect(source).toContain('event.preventDefault();');
  });

  it("clears a deleted active review deck from an effect rather than mutating state during render", () => {
    expect(source).toContain('if (reviewing && !state.decks.some((deck) => deck.id === reviewing)) setReviewing(null);');
    expect(source).toContain('}, [reviewing, state.decks]);');
    expect(source).toContain('if (!deck) return null;');
    expect(source).not.toContain('if (!deck) { setReviewing(null); return null; }');
  });
});
