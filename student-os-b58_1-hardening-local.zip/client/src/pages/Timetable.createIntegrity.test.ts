import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { describe, expect, it } from "vitest";

const source = readFileSync(fileURLToPath(new URL("./Timetable.tsx", import.meta.url)), "utf8");

describe("Timetable event creation integrity", () => {
  it("claims valid new recurring event submissions before their canonical save and resets when opened", () => {
    expect(source).toContain("const saveClaimRef = useRef(false);");
    expect(source).toContain("if (open) saveClaimRef.current = false;");
    expect(source).toContain("if (!editing && saveClaimRef.current) return;");
    expect(source).toContain("if (!editing) saveClaimRef.current = true;");
    expect(source).toContain("onSave={(data) => editing ? updateEvent(editing.id, data) : addEvent(data)}");
  });

  it("keeps create and edit details visible when canonical overlap validation rejects the save", () => {
    expect(source).toContain("const accepted = onSave(");
    expect(source).toContain("if (!accepted) {");
    expect(source).toContain("Your details are still here");
    expect(source).toContain("if (!editing) saveClaimRef.current = false;");
  });
});
