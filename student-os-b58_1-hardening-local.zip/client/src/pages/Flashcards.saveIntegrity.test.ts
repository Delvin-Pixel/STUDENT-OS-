import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { describe, expect, it } from "vitest";

const source = readFileSync(fileURLToPath(new URL("./Flashcards.tsx", import.meta.url)), "utf8");

describe("Manual flashcard dialog save integrity", () => {
  it("claims a valid card submission before canonical creation and resets on opening", () => {
    expect(source).toContain("const saveClaimRef = useRef(false);");
    expect(source).toContain("if (open) saveClaimRef.current = false;");
    expect(source).toContain("if (saveClaimRef.current) return;");
    expect(source).toContain("saveClaimRef.current = true;");
    expect(source).toContain("if (!addCard(deckId");
  });

  it("retains the draft when canonical card creation rejects a disappeared deck", () => {
    expect(source).toContain("if (!deckId) return setError");
    expect(source).toContain("saveClaimRef.current = false;");
    expect(source).toContain("Your card text is still here");
  });

  it("claims a valid deck submission before canonical creation and resets on opening", () => {
    expect(source).toContain("const deckSaveClaimRef = useRef(false);");
    expect(source).toContain("if (open) deckSaveClaimRef.current = false;");
    expect(source).toContain("if (deckSaveClaimRef.current) return;");
    expect(source).toContain("deckSaveClaimRef.current = true;");
    expect(source).toContain("addDeck({ name: name.trim()");
  });

  it("clears a removed canonical topic before rendering or saving a deck", () => {
    expect(source).toContain("const resolvedTopicId = topicId && topicOptions.some((topic) => topic.id === topicId) ? topicId : \"\";");
    expect(source).toContain("if (topicId && !resolvedTopicId) setTopicId(\"\");");
    expect(source).toContain("topicId: resolvedTopicId || undefined");
    expect(source).toContain("value={resolvedTopicId || \"_none\"}");
  });
});
