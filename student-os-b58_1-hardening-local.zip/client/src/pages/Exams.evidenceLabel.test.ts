import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { describe, expect, it } from "vitest";

const source = readFileSync(fileURLToPath(new URL("./Exams.tsx", import.meta.url)), "utf8");

describe("Exam Center readiness evidence presentation", () => {
  it("labels checklist or mixed readiness as an estimate and reserves direct-evidence language for complete direct coverage", () => {
    expect(source).toContain("const allTopicsHaveDirectEvidence = Boolean(total > 0 && briefing?.evidenceBackedTopics === total);");
    expect(source).toContain('allTopicsHaveDirectEvidence ? "Direct-evidence readiness" : "Readiness estimate"');
    expect(source).toContain("practice and quizzes provide learning evidence");
  });
});
