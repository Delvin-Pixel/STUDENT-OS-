import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { describe, expect, it } from "vitest";

const source = readFileSync(fileURLToPath(new URL("./MaterialSummary.tsx", import.meta.url)), "utf8");

describe("AI material-draft binding integrity", () => {
  it("invalidates stale material responses and saves reviewed artifacts through their originating material", () => {
    expect(source).toContain("summaryRequestMaterialRef.current = null; practiceRequestMaterialRef.current = null;");
    expect(source).toContain("if (summaryRequestMaterialRef.current !== material.storageKey) return;");
    expect(source).toContain("if (practiceRequestMaterialRef.current !== material.storageKey) return;");
    expect(source).toContain("const { draft: summaryDraft, consentAt } = value;");
    expect(source).toContain("setDraft({ ...summaryDraft, material, consentAt });");
    expect(source).toContain("setMaterialQuestionDraft({ ...value.draft, material });");
    expect(source).toContain("subject: currentTopic?.subject ?? draft.material.subject");
    expect(source).toContain("subject: currentTopic?.subject ?? materialQuestionDraft.material.subject");
  });
});
