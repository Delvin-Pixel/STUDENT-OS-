import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { describe, expect, it } from "vitest";

const source = readFileSync(fileURLToPath(new URL("./Tasks.tsx", import.meta.url)), "utf8");

describe("Manual task-dialog save integrity", () => {
  it("claims a valid dialog submission before canonical task creation and resets on opening", () => {
    expect(source).toContain("const saveClaimRef = useRef(false);");
    expect(source).toContain("if (open) saveClaimRef.current = false;");
    expect(source).toContain("if (saveClaimRef.current) return;");
    expect(source).toContain("saveClaimRef.current = true;");
    expect(source).toContain("onSave({ title: title.trim()");
    expect(source).toContain("let accepted = false;");
    expect(source).toContain("if (!accepted) return false;");
    expect(source).toContain(")) saveClaimRef.current = false;");
  });

  it("offers combined canonical manual and exam topics and synchronizes a selected topic subject", () => {
    expect(source).toContain("const topicOptions = useMemo(() => Array.from(new Map([");
    expect(source).toContain("...state.exams.flatMap((exam) => exam.topics.map((topic) => [topic.id");
    expect(source).toContain("const selected = topicOptions.find((topic) => topic.id === next);");
    expect(source).toContain("if (selected) setSubject(selected.subject);");
  });
});
