import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { describe, expect, it } from "vitest";
import { getStudyRecommendationTopicId } from "./Study";

const source = readFileSync(fileURLToPath(new URL("./Study.tsx", import.meta.url)), "utf8");

describe("Study Planner ranked recommendation handoff", () => {
  it("reads only an opaque topic ID from a ranked-action URL", () => {
    expect(getStudyRecommendationTopicId("/study?topicId=waves")).toBe("waves");
    expect(getStudyRecommendationTopicId("/study?subject=Physics&topic=Waves")).toBeNull();
    expect(getStudyRecommendationTopicId("/study?topicId=%20%20")).toBeNull();
  });

  it("resolves the incoming identity against canonical topics before pre-filling one new session", () => {
    expect(source).toContain('const directTopic = state.topics.find((topic) => topic.id === recommendedTopicId);');
    expect(source).toContain('const examTopic = exam.topics.find((topic) => topic.id === recommendedTopicId);');
    expect(source).toContain('setDialogRecommendedTopic(incomingRecommendedTopic);');
    expect(source).toContain('recommendedTopic={dialogRecommendedTopic}');
    expect(source).toContain('setTopicId(recommendedTopic?.id ?? editing?.topicId ?? "");');
    expect(source).toContain('recommendedTopic?.subject,');
    expect(source).toContain('subjectOptions.map((s) => (');
  });
});
