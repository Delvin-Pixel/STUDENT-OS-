import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { describe, expect, it } from "vitest";

const source = readFileSync(fileURLToPath(new URL("./Goals.tsx", import.meta.url)), "utf8");

describe("Manual goal dialog save integrity", () => {
  it("claims a valid goal submission before canonical creation and resets on opening", () => {
    expect(source).toContain("const saveClaimRef = useRef(false);");
    expect(source).toContain("if (open) saveClaimRef.current = false;");
    expect(source).toContain("if (saveClaimRef.current) return;");
    expect(source).toContain("saveClaimRef.current = true;");
    expect(source).toContain("if (!onSave(goal)) {");
  });

  it("keeps an omitted deadline as the canonical empty string and validates before claiming", () => {
    expect(source).toContain('import { validateNewGoal } from "@/lib/goalValidation";');
    expect(source).toContain("const goal = { name: name.trim(), category, target, current: 0, unit, deadline };");
    expect(source).toContain("const validationError = validateNewGoal(goal);");
    expect(source).toContain("saveClaimRef.current = false;");
  });
});
