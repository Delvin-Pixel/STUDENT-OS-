import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { describe, expect, it } from "vitest";

const source = readFileSync(fileURLToPath(new URL("./Settings.tsx", import.meta.url)), "utf8");

describe("Settings notification-disable integrity", () => {
  it("uses a monotonic toggle guard and compensates a stale successful registration when reminders were turned off", () => {
    expect(source).toContain("const notificationToggleVersionRef = useRef(0);");
    expect(source).toContain("const notificationDesiredRef = useRef(state.settings.notifications);");
    expect(source).toContain("const toggleVersion = ++notificationToggleVersionRef.current;");
    expect(source).toMatch(/const isCurrentToggle = \(\) =>\s*notificationToggleVersionRef\.current === toggleVersion;/);
    expect(source).toContain("if (!isCurrentToggle()) {");
    expect(source).toMatch(/await disablePush\.mutateAsync\(\{\s*endpoint\s*\}\);/);
    expect(source).toContain("await disablePush.mutateAsync({ endpoint: activation.endpoint });");
    expect(source).toContain("await unsubscribeDevicePush();");
  });
});
