import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { describe, expect, it } from "vitest";

const source = readFileSync(fileURLToPath(new URL("./StudyMaterials.tsx", import.meta.url)), "utf8");

describe("Study Material upload metadata integrity", () => {
  it("captures submission metadata and preserves the completed upload draft if canonical recording rejects", () => {
    expect(source).toContain("const submittedMaterial = { title: title.trim(), subject: resolvedSubject");
    expect(source).toContain("upload.mutate({ ...submittedMaterial, fileName: file.name, dataUrl }, { onSuccess: (stored) => {");
    expect(source).toContain("const accepted = addStudyMaterial({ ...submittedMaterial, fileName: stored.fileName");
    expect(source).toContain("if (!accepted) {");
    expect(source).toContain("Your upload details are still here.");
  });
});
