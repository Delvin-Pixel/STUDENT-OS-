import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { describe, expect, it } from "vitest";

const source = readFileSync(fileURLToPath(new URL("./Notes.tsx", import.meta.url)), "utf8");

describe("Manual note editor save integrity", () => {
  it("validates note drafts and retains create or edit details when canonical saving rejects", () => {
    expect(source).toContain("const saveClaimRef = useRef(false);");
    expect(source).toContain("if (open) { saveClaimRef.current = false; reset(note); }");
    expect(source).toContain("const validationError = validateNoteDraft(draft);");
    expect(source).toContain("if (saveClaimRef.current) return;");
    expect(source).toContain("saveClaimRef.current = true;");
    expect(source).toContain("const accepted = note ? updateNote(note.id, draft) : addNote(draft);");
    expect(source).toContain("Your details are still here.");
  });

  it("clears a removed canonical topic before rendering or saving the note", () => {
    expect(source).toContain("const resolvedTopicId = topicId && topics.some((topic) => topic.id === topicId) ? topicId : \"\";");
    expect(source).toContain("if (topicId && !resolvedTopicId) setTopicId(\"\");");
    expect(source).toContain("topicId: resolvedTopicId || undefined");
    expect(source).toContain("value={resolvedTopicId || \"_none\"}");
  });
});
