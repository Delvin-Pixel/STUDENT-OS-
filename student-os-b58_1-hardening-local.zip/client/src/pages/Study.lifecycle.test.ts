import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { describe, expect, it } from "vitest";

const source = readFileSync(fileURLToPath(new URL("./Study.tsx", import.meta.url)), "utf8");

describe("Study Planner session lifecycle controls", () => {
  it("uses canonical start and completion actions rather than generic status mutation", () => {
    expect(source).toContain('onStart={() => startSession(s.id)}');
    expect(source).toContain('onComplete={() => completeSession(s.id)}');
    expect(source).toContain('s.status === "planned" && <Button');
    expect(source).toContain('s.status === "in_progress" && <Button');
    expect(source).not.toContain('updateSession(s.id, { status })');
  });

  it("claims a valid manual dialog save before submitting the canonical session mutation", () => {
    expect(source).toContain("const saveClaimRef = useRef(false);");
    expect(source).toContain("saveClaimRef.current = false;");
    expect(source).toContain("if (saveClaimRef.current) return;");
    expect(source).toContain("saveClaimRef.current = true;");
    expect(source).toContain("const accepted = onSave({");
  });

  it("retains create and edit details when canonical overlap validation rejects the session", () => {
    expect(source).toContain("if (!accepted) {");
    expect(source).toContain("saveClaimRef.current = false;");
    expect(source).toContain("Your details are still here");
    expect(source).toContain("const accepted = editing ? updateSession(editing.id, data) : addSession(data);");
  });
});
