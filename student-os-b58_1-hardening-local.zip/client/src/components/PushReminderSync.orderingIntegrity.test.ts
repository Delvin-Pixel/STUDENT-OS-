import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { describe, expect, it } from "vitest";

const source = readFileSync(fileURLToPath(new URL("./PushReminderSync.tsx", import.meta.url)), "utf8");

describe("General device reminder synchronization integrity", () => {
  it("serializes latest-plan writes and applies shared reminder preferences to restored Focus reminders", () => {
    expect(source).toContain("const latestSyncJobRef = useRef<(() => Promise<void>) | null>(null);");
    expect(source).toContain("const requestedSyncVersionRef = useRef(0);");
    expect(source).toContain("if (syncRunningRef.current) return;");
    expect(source).toContain("while (completedSyncVersionRef.current < requestedSyncVersionRef.current)");
    expect(source).toContain("await latestSyncJobRef.current?.();");
    expect(source).toContain("requestedSyncVersionRef.current += 1;");
    expect(source).toContain("reminders = limitPlannedPushReminders([...planDevicePushReminders(state), ...(focusReminder ? [focusReminder] : [])], state);");
  });

  it("resets the automatic sync queue when reminders are disabled and compensates an in-flight registration without racing the Settings activation transaction", () => {
    expect(source).toContain("const notificationsEnabledRef = useRef(state.settings.notifications);");
    expect(source).toContain("latestSyncJobRef.current = null;");
    expect(source).toContain("requestedSyncVersionRef.current += 1;");
    expect(source).toContain("if (!state.settings.notifications) {");
    expect(source).toContain("completedSyncKey.current = null;");
    expect(source).toContain("Settings owns explicit device deactivation.");
    expect(source).toContain("if (!notificationsEnabledRef.current) {");
    expect(source).toContain("await disableDevice({ endpoint: subscription.endpoint });");
  });
});
