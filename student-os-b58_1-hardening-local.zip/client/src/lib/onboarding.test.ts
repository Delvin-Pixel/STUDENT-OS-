import { describe, expect, it } from "vitest";
import { emptyState } from "@/lib/storage";
import { restartOnboardingState } from "@/lib/onboarding";

describe("restartOnboardingState", () => {
  it("returns to onboarding without deleting existing student work", () => {
    const state = emptyState();
    state.onboarded = true;
    state.profile = { name: "Ada", age: 16, educationLevel: "Secondary", goals: ["Exam preparation"], subjects: ["Mathematics"] };
    state.tasks = [{ id: "task-1", title: "Revise algebra", subject: "Mathematics", completed: false, priority: "high", createdAt: "2026-08-12", dueDate: "2026-08-14" }];
    state.notes = [{ id: "note-1", title: "Formula list", subject: "Mathematics", content: "Area = length × width", pinned: true, createdAt: "2026-08-12T12:00:00.000Z", updatedAt: "2026-08-12T12:00:00.000Z" }];
    state.savedLessons = [{
      id: "lesson-1",
      selectionKey: "2026-08-12-maths-algebra",
      savedAt: "2026-08-12T12:00:00.000Z",
      date: "2026-08-12",
      subject: "Mathematics",
      area: "Algebra",
      topic: "Linear equations",
      title: "Solving linear equations",
      content: "Balance both sides of the equation.",
      learningGoals: ["Solve a one-step equation"],
      recap: "Keep an equation balanced.",
      diagrams: [],
    }];
    state.xp = 240;

    const restarted = restartOnboardingState(state);

    expect(restarted.onboarded).toBe(false);
    expect(restarted.profile).toBeNull();
    expect(restarted.tasks).toEqual(state.tasks);
    expect(restarted.notes).toEqual(state.notes);
    expect(restarted.savedLessons).toEqual(state.savedLessons);
    expect(restarted.xp).toBe(240);
  });
});
