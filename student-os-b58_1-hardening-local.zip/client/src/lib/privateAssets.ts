const RAW_STORAGE_PREFIXES = ["/storage/"];

export function toSafePrivateAssetPath(storageKey: string): string {
  const normalized = storageKey.trim().replace(/^\/+/, "");
  if (!normalized || normalized.includes("..")) {
    throw new Error("Invalid storage key");
  }
  return `/storage/${normalized}`;
}
