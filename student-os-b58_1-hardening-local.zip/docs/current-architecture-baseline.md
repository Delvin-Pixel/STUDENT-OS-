# Student OS Current Architecture Baseline

> **Audit status:** This is a source-level baseline, not a production-readiness claim. It records the active implementation reviewed after the two uploaded hardening prompts were merged. Controlled runtime and manual-device evidence remain required by the consolidated specification.

## Active Architecture Map

| Concern | Current active path | Source evidence | Audit interpretation |
|---|---|---|---|
| Entry and route gate | `AuthenticatedStudentOS` waits for `useAuth`; the sign-in view renders without StoreProvider; authenticated users mount `StoreProvider` keyed by `user.openId`; workspace routes wait for hydration. | `client/src/App.tsx` | Authentication controls whether the workspace shell can render. |
| Client state | One typed `StudyState` is held in StoreContext. Feature mutations flow through a single state update path. | `client/src/contexts/StoreContext.tsx`; `shared/workspaceSchema.ts` | The app remains a monolithic-workspace architecture, deliberately bounded by schema limits. |
| Local cache | Local workspace and metadata keys are encoded by authenticated `openId`; legacy unscoped state is cleared rather than adopted. | `client/src/lib/storage.ts` | Account-local browser persistence is implemented, but localStorage has scale and quota limits. |
| Cloud workspace | Protected `workspace.load/save/clear` routes derive `openId` from server context. Saves include an expected revision; server writes require a matching revision. | `server/routers.ts`; `server/workspace.ts` | The active backend is account-owned and revision-aware. |
| Database | The `users` record owns the JSON workspace, schema version, revision, and server timestamp. Push devices store opaque endpoint credentials with `openId` ownership; reminders and delivery history are linked by device ID. | `drizzle/schema.ts` | Database ownership is present, but most learning entities remain embedded in the workspace blob rather than normalized records. |
| Hydration and sync | StoreContext validates remote data, applies pending/local-vs-remote hydration policy, writes locally first, debounces a protected save, retries online failure, and merges conflict responses by stable ID. | `client/src/contexts/StoreContext.tsx`; `client/src/lib/workspaceHydration.ts`; `client/src/lib/workspaceMerge.ts` | The older claim that live StoreContext is disconnected from cloud sync is stale for the current source. |
| Private server operations | Daily Lessons, Study Assistant, learning drafts, materials, profile photo, push, and workspace routes use protected procedures. Only auth session discovery/logout remain public by design. | `server/routers.ts` | The older claim that these procedures are public is stale for the current source. |
| Materials and PDF summaries | PDF/plain-text upload validates format/size, derives storage namespace from authenticated account, resolves signed URLs only after persisted-workspace ownership check, and records explicit per-file summary consent before server AI receives a signed PDF URL. | `server/studyMaterials.ts`; `server/studyMaterialSummaries.ts`; `client/src/pages/StudyMaterials.tsx`; `client/src/pages/MaterialSummary.tsx` | A real current pipeline exists; provider and device evidence still needs to be kept separate from source evidence. |
| Profile photos | Protected upload validates declared type plus file signature and derives an account-scoped storage key on the server. | `server/routers.ts`; `server/profilePhoto.ts` | The older public/random-only ownership concern is stale for current source. |
| Push | Protected operations bind registration, sync, disable, test delivery, and history to `ctx.user.openId`; DB lookups also require endpoint plus owner. | `server/routers.ts`; `server/pushDb.ts`; `client/src/components/PushReminderSync.tsx` | Server ownership protections are present; device receipt remains a physical-device concern. |
| PWA cache | The service worker declines all `/api/` requests and caches only app shell/static resources. | `client/public/sw.js` | Authenticated tRPC responses are not intentionally written to Cache API. |
| Bundle boundary | App routes other than onboarding/dashboard are route-lazy-loaded. The dashboard defers its Recharts weekly chart, while its own non-chart content remains eager. | `client/src/App.tsx`; `client/src/pages/Dashboard.tsx` | Initial bundle splitting has been applied; specialist deferred chunks still need measured follow-up rather than speculative rewrites. |
| Learning intelligence | Four-grade flashcard scheduler retains interval, ease, review count, last/next review, retention and lapse data. Mastery uses direct quiz/practice, recall, study time, recency, and marks estimates without direct evidence. | `client/src/lib/spacedRepetition.ts`; `client/src/lib/learningIntelligence.ts` | The older assertion of no real SRS/mastery is stale for current source, subject to functional proof. |

## Current Workspace Data Model

The canonical strict schema contains profile, tasks, sessions, topics, evidence, plans, quizzes/attempts, materials, decks/cards, exams, events, transactions, goals, focus, notes, notifications, preferences, habits, lesson records, and bounded feedback. It caps high-growth arrays and rejects an entire workspace payload over 4 MB before persistence. The design currently trades database normalization for offline simplicity and whole-workspace conflict merging.

This design is valid only as a controlled interim architecture. It still has three known scale limitations: browser localStorage quota varies by browser and device; serializing the full workspace on every mutation has increasing cost; and same-ID concurrent edits follow active-device local precedence after a revision conflict. A future migration must preserve existing data and introduce versioned IndexedDB local persistence before local workspace size becomes a practical risk. High-growth server records should later be normalized in a staged order: materials metadata, notes, tasks/sessions, transactions, review history, and quiz/evidence records.

## Source-Audit Reconciliation

| Uploaded concern | Current source state | Classification | Required next evidence or repair |
|---|---|---|---|
| StoreContext does not use cloud sync | Current StoreContext directly owns hydration, revision saves, retries, conflicts, and status. An older `useWorkspaceSync` helper remains unused. | Stale claim plus confirmed dead-code ambiguity | Remove the unused helper after final call-site proof; retain StoreContext integration tests. |
| Auth is separate from the real workspace | App gates StoreProvider by authenticated identity and routes wait for workspace readiness. | Stale for the active startup path | Test account switching and expired-session behavior in controlled sessions. |
| Account switch may reveal previous workspace | `workspace.load` now includes a stable client cache-scope input based on the authenticated account; the server continues to ignore that input for ownership and derives the account from context. | **Remediated P0 risk** | Router regression proves a forged cache scope still loads only the authenticated account; controlled second-account browser testing remains required. |
| Workspace writes are blind last-write-wins | Server checks expected revision. Client merges independent stable-ID additions on conflict and resaves. Same-ID edits retain local active-device values. | Partially addressed / residual limitation | Exercise a real controlled two-session conflict and document same-record policy. |
| AI, push, photo, and material routes are public | Current router guards all listed user-owned operations with protected procedures. | Stale | Direct unauthorized and cross-owner procedure tests. |
| PDF workflow is absent | Current upload, ownership, consent, summary, review/save path exists. | Stale | Repeat controlled representative-file and cross-account proofs; maintain failure-path tests. |
| Raw material URL cannot be used cross-account | Generic direct storage paths now reject material and profile-photo key patterns. The material UI stores no raw URL and opens files only through the protected ownership-checked resolver. | **Remediated P0 authorization gap** | Unit tests cover private-key detection; synthetic direct development-server probes returned 404. Signed access remains server-side and owner-checked. |
| Session discovery duplicates private workspace | `auth.me` previously returned the full context user row, including the JSON workspace blob. It now returns identity metadata only. | **Remediated P0 data-minimization gap** | Regression verifies workspace/revision fields are absent from the session-discovery response. |
| Profile photos rely on raw storage path secrecy | New uploads store an opaque key; the shell resolves a signed URL through protected account-prefix validation. Legacy raw paths are migrated in memory to a key and are never rendered directly. | **Remediated P0 authorization gap** | Server tests cover foreign-prefix denial; synthetic direct profile raw-path probe returned 404. |
| Space repetition and mastery are only cosmetic | Current scheduler and mastery engine retain and use review/evidence data. | Stale | Exercise UI and state transitions under controlled data. |
| JSON blob/localStorage will not scale indefinitely | Both are active, though schema/payload limits are bounded. | Confirmed architecture limitation | Publish a phased IndexedDB/normalization plan; do not claim it is already solved. |
| Reset/delete explains scope insufficiently | Store reset currently clears/replaces only the local account cache and then schedules normal sync; settings text implies device-only data while the app is cloud-backed. | **Confirmed P0 data-integrity/UX defect** | Offer deliberate local reset versus protected cloud clear, accurately describe each, and test both. |
| Quick Add commits ambiguous input immediately | Parser preview exists, but submit currently creates actions without a confirmation step. | Confirmed P2 usability issue | Add a confirmation stage after P0. |
| Budget validation needs stronger bounds/warning | UI separates income/spending/balance and validates positive amount, but lacks finite bound/precision guard and overspend warning. | Confirmed P2 validation issue | Add domain validation after P0. |
| Daily Lesson fallback might masquerade as provider content | Server records fall back on provider error and UI has source distinctions, but recent logs show provider timeout fallback activity. | Partially addressed / provider reliability unproven | Verify visible provenance, bounded retry, and manual provider behavior. |
| Dates and times need a defined policy | Study calendar values use local date/time strings; server operational timestamps are Date values. | Partially addressed | Document and test the local-calendar/UTC-operational boundary around timezone transitions. |

## Comprehensive Source-Scan Outcome

The audit searched active client and server source for unresolved markers, public procedures, local/session persistence, direct storage routes, route declarations, mock/sample paths, fallback behavior, and catch/error logging. The only intentional public application procedures are account discovery/logout; health/system framework operations are outside the learner data surface. Current local persistence includes the account-scoped workspace cache plus device-only lesson cache, reminder fire log, focus reminder, layout preference, and short-lived authentication fallback token. Those device-only values must remain free of other learners' workspace records.

The scan confirmed two removal candidates: `client/src/lib/workspaceSync.ts` has no active call site because StoreContext implements the current sync lifecycle itself, and `seedSample`/`buildSampleState` have no active production call site. It also identified `ComponentShowcase` as an unregistered development component, not an active route. Expected source-labelled fallback paths exist for Daily Lessons and the Study Assistant; provider logs show actual Daily Lesson timeouts, so source labelling and retry behavior require runtime proof rather than a success claim.

## Immediate P0 Repair Order

1. Isolate or clear account-specific client query responses during sign-out and account changes, starting with workspace hydration.
2. Replace ambiguous reset behavior with explicit local reset and protected cloud-and-local wipe semantics, including clear confirmation copy.
3. Remove the unused legacy sync helper only after source and tests prove it has no call sites.
4. Add direct regression tests for each repair and then run controlled restoration/isolation/conflict validation.

## Completed P0 Remediation Evidence

The active workspace query is now partitioned by a stable account-derived cache input while server ownership remains derived exclusively from the authenticated context. The session discovery route now transmits identity metadata rather than a duplicate workspace blob. Generic storage proxy access now returns 404 for account-owned study-material and profile-photo paths; approved UI flows use protected owner checks followed by a temporary signed URL. The Settings data surface now distinguishes a non-destructive device-cache refresh from an explicit, revision-safe cloud-and-local workspace deletion. The delete flow ignores late results from pre-delete save requests so intentionally erased state cannot merge back into memory.

The verified-unused legacy sync helper and reachable fabricated sample-planner flow were removed. The post-remediation suite passed **49 test files / 163 tests**; TypeScript passed; production build passed; synthetic direct development-server requests for private material and profile-photo paths returned 404; and the protected workspace route returned 401 without a session. These checks do not replace real second-account or physical-device testing.

## Visual Verification Record

The authenticated Settings route was captured after the reset-scope repair at desktop (1280×720) and mobile (375×812). Both views displayed the new account-accurate data copy, separate **Refresh this device cache** action, and distinct **Delete workspace everywhere** action without overlap or unreachable controls. This confirms layout and copy visibility only; the destructive action itself remains covered by server authorization and controlled runtime validation rather than screenshot evidence.

## Source References

- `client/src/App.tsx`
- `client/src/main.tsx`
- `client/src/contexts/StoreContext.tsx`
- `client/src/lib/storage.ts`
- `client/src/lib/workspaceHydration.ts`
- `client/src/lib/workspaceMerge.ts`
- `client/src/lib/workspaceSync.ts`
- `client/public/sw.js`
- `server/routers.ts`
- `server/workspace.ts`
- `server/studyMaterials.ts`
- `server/studyMaterialSummaries.ts`
- `server/profilePhoto.ts`
- `server/pushDb.ts`
- `shared/workspaceSchema.ts`
