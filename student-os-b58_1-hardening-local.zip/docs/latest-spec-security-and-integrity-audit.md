# Latest Specification — Security and Integrity Audit

This audit records only the source-verified findings addressed after the latest uploaded transformation specification. It is not a blanket production-readiness claim.

| Area | Status | Verified how | Problem found | Repair |
|---|---|---|---|---|
| Push transport origin control | **VERIFIED** | Strict endpoint, ownership, scheduler, router, and TypeScript regressions | An arbitrary public HTTPS host could be registered as a push endpoint, leaving a server-side request surface beyond the intended browser push providers | Added exact allowlist for FCM, Mozilla, and Apple browser push-service hosts; retained protocol, credentials, port, and IP-literal rejection |
| Push redirects | **VERIFIED** | Transport source regression and endpoint tests | Standard fetch redirect behavior could follow an allowlisted endpoint response to a different request target | Set `redirect: "error"` on the push delivery request |
| AI cost/abuse control | **VERIFIED** | Durable limiter unit tests, protected AI route tests, live schema verification | Request limits were process-local and reset on instance restart or could diverge across instances | Added unique per-account/per-surface durable rate-limit counters and atomic increment/check claims; unavailable database fails closed for AI |
| Material upload quotas | **VERIFIED at component level** | Upload duplicate, quota, rollback, ownership, reconciliation, workspace, and TypeScript regressions; live schema verification | Material bytes were capped per request but had no durable per-account quota or content dedupe state | Added atomic per-account reservation, 100-file/50 MB limit, SHA-256 duplicate reuse, immediate rollback, and durable upload metadata |
| Material deletion/reconciliation | **PARTIALLY VERIFIED** | Canonical removal, tombstone, stale-pending, unreferenced-key, and workspace-persistence regressions | Learners had no material removal control; crashed uploads and old removed references could retain metadata quota | Added canonical removal, aged metadata reconciliation after successful workspace persistence, and 10-minute pending grace; storage intentionally has no physical delete API, so removing its final application key makes it unreachable through Student OS |

## Validation snapshot

| Check | Result |
|---|---|
| Full suite | **80 test files passed** |
| Type check | Passed |
| Source credential scan | Passed |
| Production build | Passed; primary client chunk remains **765.41 kB** before gzip and retains the documented bundle warning |
| Live schema | `ai_rate_limits`, `material_storage_usage`, and `material_uploads` created with expected uniqueness constraints |

## Remaining manual boundaries

The following remain **NOT VERIFIED in this session**: real browser-provider push endpoint compatibility for every supported device, a live provider PDF request, installed PWA material deletion/reload across separate physical devices, and physical service-worker/offline lifecycle behavior. These must be observed before any production-ready certification.
