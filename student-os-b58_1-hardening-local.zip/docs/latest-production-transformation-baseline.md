# Student OS — Latest Production Transformation Baseline

**Specification source:** `pasted_content.txt`, 1,317 available lines. The uploaded text ends mid-question in the product-coherence section, so it is treated as an available-but-truncated specification rather than a complete certification standard.

## Fresh command baseline

| Check | Result | Evidence or limitation |
|---|---|---|
| Dependency installation | **VERIFIED** | `pnpm install --frozen-lockfile` completed successfully |
| Automated tests | **VERIFIED** | **78 files / 251 tests passed** after the material-question feature |
| Type checking | **VERIFIED** | `pnpm run check` passed |
| Source credential scan | **VERIFIED** | `pnpm run verify:secrets` passed with path-safe diagnostics |
| Production build | **VERIFIED with warning** | Client and server build passed; primary client chunk is **764.95 kB** before gzip, still above the 500 kB build warning threshold |
| Lint | **ENVIRONMENT-BLOCKED** | No `lint` script exists in `package.json`; `pnpm run lint` reports `ERR_PNPM_NO_SCRIPT` |
| Live OAuth, provider AI, installed PWA push, physical offline lifecycle | **NOT VERIFIED in this session** | These require real identity/provider/device conditions |

## Current architecture map

| Specification concern | Current Student OS architecture | Verified strengths | Open risk or next review target |
|---|---|---|---|
| Application state and sync | One canonical `StudyState` in `StoreContext`, local-first account-scoped persistence, revisioned protected workspace save/load, tombstone-aware merge | Avoids duplicate learning/planner state; deletion-wins rules and account cache scoping are present | Whole-workspace document serialization remains a bounded 4 MiB bridge, not a long-term high-growth model |
| Academic state and intelligence | `learningIntelligence` supplies deterministic mastery, review, capacity, and ranking; task execution/recovery fields feed it | No opaque AI priority replacement; Today, Tasks, Focus, Plans, Quizzes, and Mastery share canonical entities | Fresh review should focus on edge cases under large workspaces, simultaneous changes, and date boundaries |
| AI proposals | Protected server-side lesson, assistant, quiz-draft, summary, and material-question procedures call structured LLM transport | Strict output schemas, bounded prompts, safe operational logging, rate limit, and learner review before quiz persistence | Rate limit architecture and untrusted-document/prompt-injection boundaries need renewed adversarial review |
| Material pipeline | Account-owned PDF upload → ownership check → signed server link → explicit per-action consent → summary/question draft → learner review → canonical quiz/flashcards | The newest action-specific consent timestamp and review checklist prevent automatic quiz creation | Real provider PDF handling and duplicate/storage quota strategy remain manual/open review targets |
| Security and privacy | OAuth/session identity binding, protected tRPC ownership, raw private-storage blocks, secret scanning/archive safeguards | Account A/B, storage, push, and AI authorization regressions exist | Push endpoint validation must be assessed against the newer strict allowlist/DNS-rebinding standard |
| Push/PWA | Account-owned subscriptions, reminder dedupe, retry, cooldown, Heartbeat dispatch, same-origin click navigation, cache exclusions for `/api` and private storage | Durable database constraints and scheduled callback authorization have test coverage | Physical delivery, redirects/DNS safety, service-worker update, and device behavior remain manual or require source-level deep audit |
| UX/accessibility/performance | Mobile-first shell, lazy routes, deferred authenticated shell/onboarding, reduced-motion global guard | Primary client bundle reduced in the earlier pass; routes protect private views | Current bundle warning remains; signed-in responsive and assistive-technology journeys require renewed hands-on verification |

## Requirement reconciliation

The uploaded specification's 35 numbered sections resolve into six active review tracks. Existing history and current source establish significant prior coverage, but the following must be treated as **review targets rather than claimed complete merely because a feature exists**.

| Review track | Existing evidence | Current status |
|---|---|---|
| Baseline, architecture, and honest evidence | Previous security, learning, quality, and validation reports; current fresh command baseline above | **VERIFIED baseline, PARTIALLY VERIFIED architecture reconstruction** |
| Session, authorization, storage, push/SSRF, AI security, and cost controls | Fail-closed session validation; protected routes; private storage resolver/proxy tests; endpoint guards; safe logs | **PARTIALLY VERIFIED — deep DNS/redirect/allowlist and scalable rate-limit review next** |
| Workspace integrity, scaling, conflicts, dates, and task lifecycle | 4 MiB contract, tombstones, merge tests, canonical task recovery and session lifecycle | **PARTIALLY VERIFIED — large-data/date/parallel-workload validation next** |
| Academic state, priority, recovery, Today, exams, materials, planner, and reviews | Single intelligence engine, connected task/Focus workflow, quizzes/mastery/reviews, newest material-question pipeline | **PARTIALLY VERIFIED — inspect coherence gaps rather than add a duplicate engine** |
| Mobile, accessibility, errors, performance, and observability | Lazy routes, reduced motion, protected screen capture, test suite, safe operational categories | **PARTIALLY VERIFIED — signed-in device and dense-data coverage still required** |
| Hostile validation, E2E, multi-account, chaos, and product coherence | Extensive unit/procedure/security regressions and documented manual limits | **PARTIALLY VERIFIED — controlled failure and product-journey trace audit next** |

## Priority order for this mission

1. **P0:** Search for a practical authorization, SSRF, document-processing, data-corruption, or cross-account failure introduced or missed since the prior audit.
2. **P1:** Verify AI proposal review gates, scalable rate-limit assumptions, material workflow reliability, conflict/date/task execution behavior, and repeatable failure handling.
3. **P2:** Measure large-state and mobile/accessibility behavior before changing architecture or splitting dependencies.

No part of this baseline is a production-readiness claim. It is a recorded starting point for the current review.
