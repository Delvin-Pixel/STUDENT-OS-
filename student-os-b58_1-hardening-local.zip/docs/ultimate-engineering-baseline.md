# Ultimate Engineering Mission — Current Baseline

This document consolidates the uploaded mission, prior hardening releases, the product-evolution increment, and the current source inspection. It is a working engineering baseline, not a production-readiness claim.

## Current architecture

| Layer | Current design | Evidence | Current concern |
| --- | --- | --- | --- |
| Client | React 19, Wouter, lazy non-initial routes, one account-scoped `StoreContext` and account-keyed local cache. | `client/src/App.tsx`, `StoreContext.tsx` | Deletions now write canonical bounded tombstones; remaining whole-blob capacity and recovery behavior still require phased audit. |
| API and authentication | Express/tRPC with Manus OAuth. `protectedProcedure` derives `ctx.user`; browser inputs do not choose a workspace owner. | `server/_core/context.ts`, `server/routers.ts` | Authenticated route coverage must be re-audited as one matrix, including stale sessions and every ownership surface. |
| Server persistence | One validated JSON workspace per `users.openId`, guarded by monotonic whole-workspace revisions. The physical workspace column is now `MEDIUMTEXT`. | `server/workspace.ts`, `drizzle/0007_oval_punisher.sql`, direct `SHOW COLUMNS` result | Keep a conservative 4 MiB application cap despite the 16 MiB physical field; continue audit of large-state recovery and transport behavior. |
| Local-first sync | Account-local state writes immediately; a debounced revision-checked server save retries after transient errors; conflicts merge by record ID plus canonical deletion tombstones. | `StoreContext.tsx`, `workspaceHydration.ts`, `workspaceMerge.ts`, `workspaceTombstones.ts` | Tombstones prevent old peer snapshots from reviving removed records. Scalar concurrent edits still follow the documented active-device merge policy and need broader product-level conflict review. |
| Private files | Account namespaced PDF/profile storage, protected URL resolver, raw private-proxy blocking. | `studyMaterials.ts`, `profilePhoto.ts`, `storageProxy.ts` | The ownership controls require a new complete IDOR and stale-session matrix, not merely source inspection. |
| AI | Protected, rate-limited Daily Lessons, Study Assistant, quiz drafts, and consent-gated material summary. | `server/routers.ts` and service modules | All contexts and fallback provenance require audit; provider success and mobile delivery remain physical/runtime validation. |
| Notifications | Account-owned browser-push subscriptions, delivery history, schedule records, device-local reminder planner. | `pushDb.ts`, `pushSchedule.ts`, `PushReminderSync.tsx` | Real installed-device delivery, expiry recovery, device switching, and account switching cannot be established by unit tests alone. |
| Learning intelligence | Deterministic priority, study plans, execution lifecycle, mastery evidence, four-grade review, exams, review queue, and local material workflow. | `learningIntelligence.ts`, `spacedRepetition.ts`, routes/pages | The model is coherent but needs end-to-end audit against recovery, capacity, and conflict semantics before expansion. |

## Confirmed P0 findings

| Finding | Confirmed evidence | Required outcome |
| --- | --- | --- |
| Workspace capacity mismatch | Confirmed and remediated. Migration `0007_oval_punisher.sql` is a non-destructive `ALTER ... MODIFY workspace MEDIUMTEXT`; it was applied and direct production `SHOW COLUMNS` returned `mediumtext`. A disposable row persisted a 3,670,028-byte UTF-8 workspace probe and was removed. | Maintain the validated 4 MiB application/backup cap, test near-limit canonical payloads, and continue monitoring whole-blob scale before any normalization migration. |
| Delete resurrection risk | Remediated for canonical entity deletes. `syncTombstones` is schema-defaulted for legacy workspaces, every existing removal/bounded-retention path records collection plus ID, and merge filters tombstoned top-level and nested-card records. Direct regressions cover delete-vs-edit, delete-vs-delete, stale re-create, nested card deletion, repeated merge, and legacy migration. | Tombstones intentionally do not expire without a peer-acknowledgement/operation-cursor protocol; retain the 20,000-marker validation bound and treat compaction as a later protocol design, not a silent cleanup. |

## Scope discipline

The current JSON-workspace architecture remains a transitional local-first design. This mission does not justify a reckless full normalized-data rewrite. Repairs will be incremental, canonical-schema validated, covered by migrations and regressions, and documented against the existing phased storage plan.

> **Evidence limit.** The deployed database column was directly queried and an isolated disposable-row capacity probe was removed after verification. Unit tests, source checks, controlled probes, and preview screenshots can verify important boundaries; real mobile OAuth, installed-PWA offline reopening, account switching, push receipt, browser variations, and provider reliability remain **REQUIRES MANUAL DEVICE TEST** until observed on physical devices.
