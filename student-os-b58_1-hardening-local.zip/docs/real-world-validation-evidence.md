# Real-world validation evidence

> **Historical validation record — not the active current-release certification.** The observations below remain preserved as evidence for their original work, but current hardening validation and manual boundaries are maintained in `59449904-production-hardening-record.md`.

This working record distinguishes **observed controlled evidence** from checks that require a real person, a physical device, or separate live accounts.

## PDF and file ownership

| Check | Evidence observed | Status |
| --- | --- | --- |
| Representative PDF storage | A 1,512-byte representative PDF uploaded beneath a disposable account scope and retrieved through a signed URL with identical SHA-256 hashes. | Observed in controlled server probe. |
| Larger PDF storage | A 1,579,336-byte representative PDF uploaded and retrieved byte-for-byte in the same controlled probe. | Observed in controlled server probe. |
| PDF summary provenance | A real controlled-account summary was generated from the representative PDF and its returned draft contained both documented concepts, `refraction` and `wave`. | Observed in controlled server probe. |
| Over-limit PDF | A structurally valid 3,263,910-byte PDF was rejected with `PAYLOAD_TOO_LARGE`. | Observed in controlled server probe. |
| Unsupported file | A `.docx` fixture was rejected with `BAD_REQUEST`. | Observed in controlled server probe. |
| Material ownership | Server-side URL resolution now verifies that the requested storage key exists in the authenticated account workspace before requesting any signed URL. A cross-account access regression confirms rejection before storage is contacted. | Automated contract evidence. |
| Physical browser upload | Upload, summary, offline browser state, and signed-out/second-account behavior through a real browser session remain manual acceptance checks. | **REQUIRES MANUAL DEVICE TEST** |

## Cloud sync and local-first state

A disposable cloud account restored a representative workspace containing a task, note, exam, timetable event, flashcard deck, goal, and `GHS` setting. A stale simulated second device hit a real revision conflict; its independent note was ID-merged with the first device’s task, then saved at the next revision. The final cloud workspace contained both new IDs with no duplicate IDs.

Browser-native offline mode, physical account switching, and installed-PWA recovery still require a real device or controlled second browser profile.

### Post-audit P0 hardening evidence

The post-audit router and client contracts partition the workspace and private push-history query caches with a stable account scope while deriving authorization only from the server session. A forged workspace cache scope still resolved only the trusted authenticated account in regression coverage. Session discovery no longer serializes the workspace blob. The generic storage proxy now returns `404` for synthetic account-owned study-material and profile-photo paths, while normal account-owned UI access is resolved through protected signed-URL procedures. A direct unauthenticated development request to `workspace.load` returned `401`.

The Settings data actions now distinguish **Refresh this device cache** from **Delete workspace everywhere**. The deletion path is revision-safe, reports a cloud conflict/unavailability instead of a false success, and ignores late pre-delete save results. Desktop and mobile settings captures verified that the two actions are separately visible and reachable. This is controlled UI and contract evidence; a full second-account browser switch and a physical offline/reconnect cycle remain **REQUIRES MANUAL DEVICE TEST**.

## Notifications

The server-side notification regression suite passed for VAPID credential handling, accepted/retryable/expired delivery-status classification, bounded private delivery history, scheduled-dispatch guarding, and payload construction. These checks provide contract evidence for the server path, not proof that a particular browser or phone displayed a notification.

Permission prompts, device registration, visible delivery, disable/re-enable behavior, logout/login behavior, and a second-device result are all **REQUIRES MANUAL DEVICE TEST** checks. No physical push delivery is claimed from this environment.

## Performance work

Route-level lazy loading reduced the initial dashboard JavaScript asset from 1,952,010 bytes to 1,387,923 bytes. Deferring the dashboard’s non-critical Recharts weekly chart reduced it further to 990,485 bytes: a measured **49.2%** reduction from the baseline. The assistant route and budget route were opened successfully after their deferred code was requested. The AI/diagram and syntax-rendering chunks remain intentionally deferred and continue to warrant future optimisation.

## Responsive review

Desktop previews of the dashboard, Today, Materials, and PDF Summary routes loaded successfully. Mobile previews confirmed the dashboard and consent-led material explanations remain readable. The review exposed a mobile layout issue: the floating Quick Add button can overlap the lower material/PDF form controls. A targeted layout correction is tracked before final release.

The post-audit hardening build was also reviewed at desktop (1280×720) and mobile (375×812) on the authenticated dashboard. Both layouts rendered the account workspace, educational lesson loading state, plan cards, quick actions, navigation, and compact mobile hierarchy without a visible overlap or clipped control. This is visual layout evidence only; it does not prove lesson-provider availability or physical-device notification behavior.

## Published endpoint check

The published Student OS URL rendered successfully in the available browser session. A credential-omitted browser fetch to the protected workspace procedure could not complete from that browser context, and the sandbox command-line TLS probe also could not establish a connection. As a stateless alternative, direct extraction of the published `workspace.load` procedure returned `UNAUTHORIZED` with HTTP status 401. The public route and protected procedure boundary are therefore observed live; physical sign-in/switching remains **REQUIRES MANUAL DEVICE TEST**.

## Final validation table

| Area | Status | Tested how | Problems found | Fix applied |
| --- | --- | --- | --- | --- |
| Authentication | **Observed + manual follow-up** | Protected workspace route returned `401` without a session; auth/session regression now verifies workspace JSON is absent from session discovery. | Real provider sign-in/switch sequence was not performed by this environment. | Minimized `auth.me` to identity metadata only; manual provider sign-in remains required. |
| Cloud persistence | **Observed in controlled account** | Disposable account wrote and reloaded representative tasks, notes, exams, events, decks, goals, and currency from the real workspace store. | No missing representative records observed. | None required. |
| Local-first storage | **Automated contract evidence** | Hydration regression retains account-local workspace when cloud fetch fails. | Native browser storage was not cleared/restarted here. | **REQUIRES MANUAL DEVICE TEST** for browser restart/storage-clear scenario. |
| Synchronization | **Observed in controlled account** | Real revision conflict between simulated devices was merged and saved; independent task and note IDs both survived. | No duplicate IDs observed. | None required. |
| Offline mode | **Partial; manual follow-up** | Hydration regression preserves pending offline work; storage outage test returns a safe error without success state. | Physical network disable/reconnect was not possible in this environment. | **REQUIRES MANUAL DEVICE TEST** for actual browser offline/reconnect sync. |
| Multi-device restore | **Controlled simulation; manual follow-up** | Cloud workspace restored into a simulated second device state, then merged changes back to the first cloud view. | No real second installed device was available. | **REQUIRES MANUAL DEVICE TEST** for device A/B account sign-in. |
| Account isolation | **Observed server contract** | Cross-account material URL resolver rejects absent ownership before storage access; forged workspace cache scope retains trusted server identity; raw synthetic material/profile paths returned `404`. | Real second provider account not used. | Added query-cache partitioning, minimized auth payload, protected avatar access, and generic private-key blocking. |
| PDF upload | **Observed in controlled account** | Real 1.5 KB and 1.58 MB PDFs uploaded and retrieved byte-for-byte; over-limit 3.26 MB PDF rejected. | Mobile Quick Add initially overlapped material forms. | Hid the mobile floating Quick Add control on material/PDF-summary routes. |
| PDF AI summary | **Observed in controlled account** | Summary created from the real representative PDF contained `refraction` and `wave`; explicit consent and workspace ownership gates executed first. | No real learner-browser interaction performed. | Added server ownership verification before download URL resolution. |
| Notifications | **Server contract only** | Credential, schedule guard, payload, and delivery-history regressions passed. | No physical notification permission or delivery was observable. | **REQUIRES MANUAL DEVICE TEST** for permission, registration, delivery, disable, logout/login, and second device. |
| AI features | **Partial** | Protected learning-draft and material-summary regressions plus a real PDF summary probe passed. | Preview logs showed Daily Lessons timing out and falling back to its local teaching scaffold. | Fallback preserves the learner experience; live provider reliability remains **REQUIRES MANUAL DEVICE TEST**. |
| Search | **Automated + visual route evidence** | Global search regression includes tasks, notes, quizzes, materials, plans, and topics; related routes rendered. | No issue observed. | None required. |
| Dashboard | **Responsive visual evidence** | Desktop and 375 px mobile previews rendered the account workspace; deferred assistant/budget routes also rendered. | Weekly chart was part of the initial bundle. | Deferred Recharts chart behind a loading boundary. |
| Performance | **Observed improvement** | Measured initial asset reduced from 1,952,010 to 990,485 bytes after route/chart splitting. | Deferred AI/diagram/syntax chunks remain large when those features are opened. | Lazy-loaded specialist routes and weekly chart; retain further chunk work as an optimisation opportunity. |
| Production build | **Passed** | Final run: 46 Vitest files / 155 tests, `tsc --noEmit`, and production build passed. No lint script is configured. | Vite still warns about large deferred chunks. | No functionality was removed; warnings documented. |
