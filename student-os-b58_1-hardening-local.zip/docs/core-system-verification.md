# Student OS Core-System Verification Record

**Scope.** This record validates the account-bound workspace foundation before further feature expansion. It covers authentication boundaries, cloud persistence contracts, account-scoped browser storage, initial hydration, offline handling, conflict behavior, and restoration. It does not treat code inspection or simulated tests as proof of a real OAuth sign-in on a physical second device.

> **Release decision:** every testable core guarantee listed below passed. The remaining items are real-device confirmations that require a learner’s own account and browser or phone; they are intentionally not marked as passed here.

## Evidence summary

| Guarantee | Observed evidence | Result | Confidence boundary |
| --- | --- | --- | --- |
| Unauthenticated callers cannot load a workspace | Router-level test rejects `workspace.load` without a session before storage access. A public production probe returned homepage `200` and unauthenticated `workspace.load` `401`. | Passed | Live request confirmed the API boundary; no private workspace content was requested or inspected. |
| Server owns identity | `workspace.load`, `save`, and `clear` use `ctx.user.openId` from the protected server context; the browser cannot choose an owner identifier. The route test confirms the server passes the authenticated account ID to storage. | Passed | Automated router contract. |
| Cloud persistence is revision-safe | Workspace writes compare the expected revision and increment only on successful matching writes. A conflict returns the current cloud revision and workspace for client merge. | Passed | Server contract and regression coverage; no production learner data was altered. |
| Account-local cache is isolated | Cache and metadata keys include the encoded authenticated `openId`. Tests show the same account restores its cache while another account receives a clean workspace; unowned legacy data is not adopted. | Passed | Automated storage behavior. |
| A new device restores a saved account | The hydration policy adopts a valid cloud workspace when the device has no pending local write. Tests include a returning profile and task restored into a fresh local workspace. | Passed | Simulated fresh-device workflow; physical second-device sign-in remains manual. |
| Offline work remains local-first | Local state is saved before cloud upload. Pending metadata retains the workspace revision; hydration preserves a pending local change rather than overwriting it with a remote copy. Browser-online events and a bounded retry re-attempt failed cloud saves. | Passed | Automated state-policy and source-path coverage; actual browser offline toggle remains manual. |
| Concurrent safe additions survive a revision clash | On a stale revision, the client merges independently identified records, retains the active local version for same-record edits, then retries against the current revision. | Passed | Regression coverage for merge behavior. |
| Older cloud workspaces still restore | The canonical schema now defaults a missing legacy `settings.currency` to `GHS`. The server serializes validated canonical output, and client hydration tests prove a legacy workspace is restored rather than discarded. | Passed | Automated compatibility regression. |
| Workspace UI cannot flash before hydration | The app first requires a user, mounts `StoreProvider` keyed by `user.openId`, then holds the router at a workspace loading view until hydration is ready. | Passed | Source audit and startup-routing coverage. |

## Repairs made during this validation

The audit found a genuine compatibility risk rather than treating the prior release as sufficient evidence. A cloud workspace saved before currency selection was introduced could be rejected by strict raw validation on a new device. The workspace schema now supplies `GHS` when that legacy field is absent, and the server persists the normalized validated representation on the next save.

The audit also tightened account ownership in Settings data paths. Imports, reset, and onboarding restart now write only to the active account’s local cache. Failed cloud mutations now retain local data and schedule a retry while the browser is online. The hydration decision itself was extracted into a tested policy so restore, pending-local, and failed-cloud outcomes are directly covered.

## Automated validation log

| Validation command or check | Observed result |
| --- | --- |
| Focused identity, server workspace, restore, local storage, hydration, isolation, merge, and startup suite | **8 files, 35 tests passed**. |
| Full project suite | **38 files, 135 tests passed**. |
| TypeScript | `pnpm exec tsc --noEmit` completed successfully. |
| Production build | `pnpm run build` completed successfully. The build emitted chunk-size warnings only; these are a performance follow-up, not a correctness failure. |
| Production unauthenticated boundary probe | Homepage returned **200**; unauthenticated `workspace.load` returned **401**. |
| Mobile visual review | The authenticated preview rendered the clean first-workspace onboarding layout at 375×812. The preview held an active development session, so this was not treated as a signed-out OAuth test. |

## Required real-device confirmations

The following checks cannot be honestly completed from automated sandbox validation because they require a real identity provider session, another browser profile or device, and in some cases an installed PWA. They are the final acceptance checks, not known failures.

| Manual check | Expected observable result |
| --- | --- |
| Sign in on a second phone or laptop with the same account | The existing profile, tasks, timetable, budget currency, and other cloud-synced workspace data appear after the short loading stage. |
| Sign out from account A and sign in as account B on the same browser | Account B sees its own workspace or clean onboarding only; no A profile, task, note, lesson, or setting appears. |
| Create a task while offline, close/reopen the browser, then reconnect | The task remains locally; the sync indicator shows Offline or Changes pending and later returns to Synced after reconnecting. |
| Make independent changes on two signed-in devices | Both independently created records remain after sync; a same-record edit follows the active-device conflict rule. |
| Clear browser site data on a second device, then sign in again | The account’s cloud workspace restores rather than beginning with an empty dashboard. |

## Conclusion

The testable implementation is now ready for release: its account boundary, storage ownership, cloud hydration, offline preservation, conflict path, and legacy-compatibility path have evidence behind them. This record deliberately does **not** claim that a physical provider login, true cross-device restoration, or installed-PWA offline behavior has already been personally exercised. Those outcomes require the listed learner-side confirmations after the release is live.
