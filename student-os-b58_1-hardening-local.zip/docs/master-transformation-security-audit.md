# Production-Excellence Security Audit — Phase 2

**Audit status:** source-level, database-backed, and automated regression validation completed on 2026-08-23. This is an evidence record, **not** a production-readiness certification. The physical-device, real OAuth-provider, and real push-provider checks listed below remain manual.

## Scope and conclusion

This pass examined the currently deployed Student OS surfaces that can expose account data, issue an authenticated side effect, invoke a provider, or schedule background delivery. The review used source inspection, targeted adversarial regressions, the full Vitest suite, a source-only credential scan, and a production build. No secret values were read, recorded, or included in this document.

| Surface | Adversarial condition exercised | Verified control | Evidence |
|---|---|---|---|
| Session/JWT | Missing or weak signing configuration; malformed or foreign-app claim; provider omits display name | Signing and verification fail closed for a secret under 32 bytes; claim must match the current app ID; `name` is non-authoritative and may be empty | `server/sessionSecret.test.ts`, `server/sessionIdentity.test.ts`, `server/_core/sdk.ts` |
| OAuth identity sync | Provider response returns a different account identifier after a valid session is verified | Sync refuses identity substitution before any user record is updated | `server/sessionIdentity.test.ts`, `server/_core/sdk.ts` |
| OAuth/log privacy | Callback, JWT verification, and OAuth user-sync exceptions contain hostile text | Only stable error categories are logged; raw error objects/messages are not emitted | `server/sdkLogging.test.ts`, `server/safeOperationalLog.test.ts`, `server/_core/oauth.ts` |
| Anonymous API access | Direct workspace, AI, material, profile, and push calls without a session | Private procedures are protected; existing direct unauthenticated route regressions remain in the suite | `server/workspace.auth.test.ts`, `server/pushOwnership.test.ts`, AI/material access regressions |
| Account A/B isolation | Account B claims, schedules, reads history for, or disables Account A’s endpoint | Ownership is derived from `ctx.user`; endpoint ownership cannot transfer during duplicate-key races | `server/pushOwnership.test.ts`, `server/pushDb.race.test.ts`, `server/pushDeliveryHistory.test.ts` |
| Private storage | Guessed material/photo key, encoded key, backslash-separated key, malformed escape | Generic storage route rejects all private forms before it can request a signed URL; protected routes enforce ownership | `server/storageProxy.test.ts`, `server/studyMaterials.access.test.ts`, `server/studyMaterialSummaries.access.test.ts` |
| Storage/provider logs | Forge presign error body or thrown exception contains sensitive data | Proxy no longer reads or logs raw upstream bodies; only safe operational categories remain | `server/storageProxyLogging.test.ts`, `server/_core/storageProxy.ts` |
| AI/provider configuration | Empty Forge model credential or upstream failure | Model request fails closed; upstream bodies are not shown to learners or server logs | `server/llm.security.test.ts`, `server/_core/llm.ts` |
| Immediate push test | Repeated or concurrent authenticated test requests | Database-backed per-device 60-second claim prevents test-notification spam | `server/pushTestCooldown.test.ts`, migration `0010_small_black_knight.sql` |
| Push endpoint SSRF | HTTP, localhost, IPv4/IPv6 literal, userinfo, or nonstandard-port endpoint | Router, persistence, and transport reject unsafe endpoints before storage or fetch | `server/webPushEndpointSecurity.test.ts`, `server/webPush.ts`, `server/pushDb.ts` |
| Scheduled dispatch | Anonymous callback, unrelated Heartbeat task, deployed task | Authentication plus exact task UID check gates queue inspection and delivery | `server/pushScheduleAuthorization.test.ts`, `server/pushSchedule.test.ts`, `server/pushSchedule.ts` |
| Duplicate reminders | Prior data contains duplicate device/dedupe pairs; concurrent plan writes | Historical rows were reconciled, a database uniqueness constraint now enforces the key, and application dedupe remains defensive | migration `0009_secret_wendell_vaughn.sql`, `server/pushReminderDedupe.test.ts` |
| Source packaging | Secret-bearing managed project configuration and build artifacts | Source archive excludes managed configuration, env files, build/dependency/log artifacts and self-validates archive content | `scripts/create-source-archive.sh` |
| Source release gate | Accidental credential literal in a tracked/unignored source file | `pnpm run verify:secrets` scans paths only and fails delivery on likely credential literals | `scripts/check-source-secrets.sh`, `package.json` |
| Owner notifications | Upstream failure body or exception includes private data | Raw response bodies and exception objects are never logged | `server/ownerNotificationLogging.test.ts`, `server/_core/notification.ts` |

## Validation record

| Command or check | Result |
|---|---|
| `pnpm test` | **76 test files, 238 tests passed** |
| `pnpm run check` | Passed |
| `pnpm run verify:secrets` | Passed; output contained no credential values |
| `pnpm run build` | Passed; build retains a documented primary-chunk warning (898.10 kB), not a security failure |
| Live database integrity check from the preceding repair | Duplicate `(deviceId, dedupeKey)` groups: **0** after migration; unique dedupe constraint and test-cooldown column were applied |

## Required owner / secret-manager action

The managed project configuration artifact was treated as a potentially compromised credential source, excluded from source packaging, and confirmed untracked. **Rotation cannot be performed safely from application source.** The project owner must rotate the affected managed secrets through the platform secret manager and invalidate any matching external credentials. This audit intentionally does not disclose values, key names beyond already configured environment variable identifiers, or where those secrets appeared.

## Explicit manual checks still required

| Scenario | Why automated evidence is insufficient |
|---|---|
| OAuth sign-in on each supported provider/device | Requires a real provider account, redirect, cookie policy, and browser session |
| Installed PWA push receipt, vibration, and notification click behavior | Requires a physical device, browser permission, service-worker state, and push provider delivery |
| Real LLM provider success and provider fallback latency | Requires a live upstream model response and governed provider credentials |
| Offline reconnect and cache refresh on a physical device | Requires browser storage pressure, installed-worker lifecycle, and network transitions |

## Follow-up security rules

Future work must continue to use `protectedProcedure` for private server state, derive authorization from `ctx.user` rather than client-provided cache identifiers, resolve private storage only through ownership-checked protected routes, use the one existing StoreContext/workspace synchronization model, and avoid logging raw exceptions, provider bodies, private material, cookies, JWTs, or endpoint credentials.
