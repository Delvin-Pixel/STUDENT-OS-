# Uploaded Directive — Initial Reconciliation

> **Historical reconciliation — superseded for current-release claims.** This document preserves the original directive analysis and associated boundaries. The active production-hardening record carries the current validation and release evidence.

This record covers the available 1,409-line directive. It is a working evidence document, not a claim that every requested capability has already been implemented.

| Directive area | Current source finding | Status | Next action |
|---|---|---|---|
| Authentication landing | `App.tsx` used one ambiguous action. The landing now presents separate **Create an account** and **Log in** actions, both preserving the existing nonce-bound OAuth redirect. The configured provider owns the final account registration/sign-in decision. | Partially verified | Test the real provider journey manually; do not invent a second local account system. |
| AI request boundaries | AI runs server-side through protected tRPC procedures and durable limits. Existing modules include lessons, Study Assistant, material summaries/questions, quiz drafts, and schedule drafts. | Partially verified | Complete inventory and reconcile prompt/context behavior per surface. |
| Schedule proposals | AI proposals use strict schemas, learner consent/review, capacity, recurring blocks, session overlaps, preferred productive windows, and deadline-risk warnings. | Verified by controlled tests | Real provider acceptance remains manual. |
| Quiz architecture | Canonical quizzes, attempts, feedback, learning evidence, and reviewed AI drafts already exist. The directive’s required 50-question generation and server-authoritative assessment require careful reconciliation because current canonical quizzes are intentionally bounded and local-first. | Not yet reconciled | Inspect source and design a safe migration path rather than creating a duplicate quiz engine. |
| Curriculum-aware subjects | Existing profile subjects and topic links are present, but country/system/verified-curriculum catalog requirements need source and model audit. | Not yet reconciled | Assess data model, authoritative-source boundaries, and onboarding impact. |

## Source-verified AI capability inventory

| Capability | Server module | Controlled boundary observed |
|---|---|---|
| Daily lesson generation and questions | `server/lessons.ts` | Protected procedure, bounded request schemas, server-side provider call and fallback path. |
| Study Assistant and requested visuals | `server/studyAssistant.ts`, `server/mediaPrompt.ts` | Protected procedure, bounded question/context, timeout, provider-independent fallback, separately guarded media generation. |
| General quiz drafts and deadline schedule proposals | `server/learningDrafts.ts` | Strict structured responses, validation before return, durable per-account AI surface limit in router, learner review before canonical mutation. |
| Material summaries and practice questions | `server/studyMaterialSummaries.ts` | Account-owned material access, action-specific consent, signed server access, strict draft validation. |

No browser component was found directly calling the server-side LLM helper. The next audit stage will compare prompts, selected context, response-length controls, error recovery, and tests across these centrally invoked capability modules.

The completed source inventory confirms that model calls are confined to server modules and route through the shared `invokeLLM` helper: lessons, Study Assistant, media prompt preparation, structured learning drafts, and protected material summaries/practice drafts. Each observed AI feature therefore remains server-side rather than exposing a browser credential path; surface-specific validation and fallback behavior remain intentionally localized to the capability module.

## Cross-surface AI policy audit

The current source audit compared every protected model surface through `server/routers.ts`. Daily lesson generation and lesson Q&A, Study Assistant, generic quiz drafts, schedule drafts, material summaries, and material-derived practice questions are all protected procedures and apply a durable per-account AI-surface limit before capability code runs. No browser-side model call or client credential path was found.

| Surface | Context boundary and output control | Canonical mutation boundary | Status |
|---|---|---|---|
| Daily Lessons | Bounded subject, branch, topic, education level, and optional age; structured lesson schema; Q&A accepts at most 5,000 characters of the active lesson context and has a direct local fallback. | A lesson answer or generated visual does not directly alter learner workspace state. | **VERIFIED at source level** |
| Study Assistant | The client sends its 1,400-character profile summary only for clearly personal planning/deadline/progress questions; generic factual questions omit it. Responses are server-side, capped at 600 completion tokens, and use a direct fallback. | Answers remain conversational artifacts; learner feedback is stored through the canonical workspace action. | **VERIFIED at source level** |
| Quiz and schedule drafts | Learner-selected context is capped at 1,200 characters; JSON schemas and server-side schedule safety checks reject malformed, over-capacity, outside-window, and overlapping output. | Drafts require learner review before the canonical quiz or session mutation. | **VERIFIED at source level** |
| Material summary and practice drafts | Only a selected account-owned PDF is signed after action-specific consent is durably recorded; strict bounded schemas parse provider output. | Summaries remain review drafts. A material-derived quiz requires every proposed answer and explanation to be checked before saving. | **VERIFIED at source level** |

### Verified P1 repair — resilient tutor model selection

Study Assistant and Daily Lesson Q&A previously requested `gpt-5-mini` by name even though their other AI surfaces select a compatible model from the server catalog. If that historical identifier was unavailable, the tutor path would use its local fallback despite another compatible server model being available. Both tutor surfaces now prefer an available compatible model in a controlled order and only attach `gpt-5` reasoning parameters to compatible models. If the catalog cannot be reached, they defer model choice to the server default; their existing output validation, token/time limits, local fallback behavior, and source labels remain unchanged. Regression coverage verifies a non-`gpt-5` compatible selection and preserves direct fallback behavior.

The lesson Q&A contract also now honors its validated `wantsMedia` field as well as explicit visual-request wording. This ensures a structured tutor response can request an educational visual even when the learner uses wording outside the narrower keyword pattern, while media-generation failure still returns the text answer alone.

The AI resilience increment passed **86 Vitest files / 283 tests**, TypeScript checking, the source credential-literal scan, and the production build. The production bundle still reports the pre-existing 767.31 kB main JavaScript warning before gzip; this repair does not claim a performance resolution. Live provider catalog, model response, image generation, and device acceptance remain manual boundaries.

## Controlled exam-evidence and timetable-capacity repair

The Exam Center and deterministic planner audit identified two source-level learning-loop defects. First, a learner-set exam-topic `mastered` label could award XP and enter the fallback readiness estimate at a strong score without direct quiz, practice, or recall evidence. The label is now a clearly estimated planning signal capped below the strong-topic threshold; it awards no XP and does not cause adaptive planning to omit the topic. Direct evidence remains the only path to a non-estimated strong performance signal.

Second, the adaptive exam-plan and missed-plan-recovery paths reserved active dated sessions and due-task work but did not reserve recurring timetable blocks. Both now account for matching local-weekday events when calculating capacity and when selecting a free evening slot, preventing a generated or recovered revision block from overlapping a recurring class. Focused deterministic regressions cover both initial-plan and recovery cases. This preserves the existing separation between recurring timetable records and dated study/exam/task records; it does not duplicate schedules or claim manual calendar/device validation. Full validation passed **92 Vitest files / 296 tests**, TypeScript, the credential-literal scan, and the production build; provider/device acceptance remains outside this controlled result.

## Schema-first architecture design — not implemented

The directive asks for a trusted 50-question assessment path and a curriculum-aware subject model. Source inspection confirms that neither is a safe page-only enhancement: the current product deliberately treats quizzes as learner-owned local practice stored in the revisioned workspace. The assessment runner scores answers in the browser and immediately appends a local `QuizAttempt` and topic evidence. The user table has only the workspace blob and operational tables for push, AI limits, and materials; it has no relational assessment/session/response records. Similarly, the onboarding profile stores `educationLevel` plus an array of learner-selected subject labels, with static presets and custom values; it stores no country, education system, catalogue version, or official-subject provenance.

| Directive goal | Verified current boundary | Safe future design | Status |
|---|---|---|---|
| Trusted 50-question assessment | Local `StudyQuiz` is bounded to 100 questions, browser `scoreQuiz` determines the result, and `recordQuizAttempt` writes directly to the account workspace. This is useful for practice but not a trusted grade. | Add protected relational assessment sessions and immutable question snapshots. Return only learner-visible question fields; grade answer submissions server-side. Retain current local quizzes as **practice**, not as trusted sessions. | **NOT IMPLEMENTED** |
| Durable in-progress recovery | Quiz runner state (`index` and answers) is React-local; reload ends the attempt. | Persist the active server session plus answer selections with a revision/updated-at field. Resume only through `ctx.user.openId` ownership checks. | **NOT IMPLEMENTED** |
| Idempotent submission and verified result | No protected submit/grading procedure or submission key exists. | Require a client-generated idempotency key on protected session start/submit; use unique owner/session keys and return the first finalized result on retries. | **NOT IMPLEMENTED** |
| Country/system curriculum provenance | Profile has no country/system/catalogue fields, and static presets/custom labels share the same string array. | Keep existing `subjects: string[]` for compatibility. Add optional `curriculumContext` plus per-subject provenance (`catalogue` or `custom`), a catalogue identifier/version, and official-source metadata. | **NOT IMPLEMENTED** |
| Ghana verified seed | Official Ghana sources are documented above, but runtime onboarding neither asks for Ghana/system nor labels any choice official. | Release a versioned Ghana-only catalogue only after source data is normalized, cited, reviewed, and separately tested. Custom subjects must remain visibly custom. | **NOT IMPLEMENTED** |

### Proposed trusted-assessment contract

The future migration should begin in `drizzle/schema.ts`, followed by generated and reviewed SQL applied through the schema workflow. An `assessment_sessions` table should hold an opaque server ID, owner `openId`, source quiz reference, topic/exam references where applicable, status (`in_progress`, `submitted`, `graded`, `expired`), an immutable question-set version, start/submit/finalize timestamps, bounded question count, and a unique owner-scoped idempotency key. An `assessment_questions` table should snapshot prompt, options, correct option, explanation, and ordering for that session. `assessment_responses` should be unique per session/question and hold only the learner selection plus an updated timestamp. The server should grade the immutable snapshot in one transaction, write result fields to the session, and make retry responses idempotent.

The protected API sequence should be `create → resume/read → save response → submit`. Every query and mutation must derive ownership from `ctx.user.openId`; neither the browser's cache scope nor a workspace-provided account ID may authorize an assessment. After server grading, the browser can reconcile a **read-only result summary** into the canonical workspace as learning evidence. It must not accept a browser-provided score as trusted or overwrite an existing server-finalized result. The legacy practice runner can remain available offline, but its UI and evidence must stay labelled provisional/local practice.

### Proposed curriculum-provenance contract

The lowest-risk profile change is an optional `curriculumContext` that adds country, education-system ID, catalogue ID/version, and an optional mapping from existing subject labels to provenance. Existing profiles remain valid because the current `subjects` labels are untouched. The client type, `shared/workspaceSchema.ts`, empty-state/default migration, cloud payload validator, and profile patch path must all change together; the workspace schema version must advance only with a tested compatibility transform for cached older blobs. A catalogue entry should carry a stable subject ID, display label, applicable education bands, source URL/title, retrieval/review date, and catalogue version. It should never infer an official subject from a custom label or an LLM response.

The two migrations should not be combined. Curriculum context can remain workspace-backed and optional. Trusted assessment requires server authority and relational persistence, so it must be planned, migrated, tested for ownership/idempotency/retry, and rolled out separately. This separation preserves the single StoreContext local-first model and avoids describing an unbuilt server assessment as already canonical.

## PWA, offline, and authenticated-session boundary audit

The installed-app cache uses network-first navigation and code loading with offline fallback, while excluding `/api/` and `/manus-storage/` from the device-wide Cache API. Push payload URLs are constrained to the current origin before a window is opened or navigated. The app registers the worker with `updateViaCache: "none"`, so a subsequent online launch revalidates the service-worker script rather than indefinitely retaining a prior app shell.

Workspace hydration is account-scoped at every source-controlled layer: the application remounts `StoreProvider` by authenticated `openId`; React Query includes a display-only account cache scope; browser state and revision metadata use encoded `openId` keys; and server workspace operations derive authorization only from `ctx.user.openId`. A clean remote copy supersedes an idle local cache, while pending offline work remains local until it can sync. Revision conflicts merge canonical collections with tombstone protection; cloud persistence strips device-private AI answer ratings before writing.

### Verified P1 repair — cookie-only application session boundary

The browser previously forwarded a runtime-injected `sessionStorage` bearer value whenever it existed, and the server accepted that bearer value whenever the regular cookie was absent. Although intended for embedded previews, this made a browser-readable session path available outside the normal cookie boundary. The repair removes that fallback entirely: the client never reads or forwards a runtime session-storage token, and the server authenticates application requests only with its signed session cookie. Direct regressions now prove that a valid bearer-only session is rejected and a valid cookie remains accepted even when a bearer header is present. The normal nonce-bound OAuth flow is unchanged. Full release validation passed **86 Vitest files / 285 tests**, TypeScript, the source credential-literal scan, and the production build. The main chunk remains 767.10 kB before gzip, so this repair does not claim a performance resolution.

## Production bundle boundary increment

The prior shared build chunk measured 767.10 kB before gzip and triggered the production-size warning. The build configuration now separates charting, UI primitives, React runtime, query/tRPC helpers, icons, and routing; PDF/canvas export libraries remain independently dynamic. The largest resulting JavaScript asset is 428.14 kB, and the 500 kB warning is absent from the validated production build. This confirms a source-controlled delivery-boundary improvement, not end-to-end performance or accessibility completion: route loading, real networks, browser cache behavior, installed-PWA updates, and device assistive-technology use remain manual evidence gaps.

## Interaction semantics increment

The global Notifications control previously nested a button within a navigation link. The audit replaced that invalid composition with a single link receiving the shared button styling through `asChild`, preserving the route, unread badge, visible focus contract, and accessible label. The focused regression prevents reintroducing the nested interactive elements. Full release validation passed **87 Vitest files / 286 tests**, TypeScript, the source credential scan, and the production build. This is a source-level semantic repair; manual keyboard order, screen-reader announcements, zoom, and touch-target acceptance remain open validation boundaries.

## Search-dialog focus-management increment

The custom global search overlay used `role="dialog"` without the shared modal primitive that provides focus containment and modal semantics. It now uses the shared controlled dialog, including a hidden dialog title and deliberate input focus on open. Search result navigation and explicit close still close the modal through the same controlled state. A focused regression guards against returning to the hand-rolled dialog. Full release validation passed **87 Vitest files / 287 tests**, TypeScript, the source credential scan, and the production build. This is source-controlled dialog behavior only; manual assistive-technology and physical keyboard validation remain explicit boundaries.

## Quick Add accessible-name increment

The Quick Add modal used the shared dialog but omitted a dialog title. It now exposes a visually hidden “Quick add” title, giving the focused modal a stable accessible name while preserving its shortcut, mobile trigger, input autofocus, review gate for planned sessions, and canonical local-first mutations. A focused regression protects the title contract. Full release validation passed **88 Vitest files / 288 tests**, TypeScript, the source credential scan, and the production build; manual screen-reader and keyboard acceptance remains explicitly open.

## Reminder queue and delivery-history source evidence

The notification path remains connected to canonical learner state rather than a parallel scheduler: Settings writes preferences/custom reminders through `StoreContext`; the client planner derives bounded future reminders from tasks, exams, daily goals, streaks, saved lessons, custom reminders, and active focus state; and the protected server replaces unsent reminders for the account-owned browser endpoint. The current planner covers a fourteen-day horizon for recurring study-plan, daily-goal, and daily custom reminders, so ordinary day rollover does not depend on an open tab at midnight.

Server delivery history records technical status only and is scoped by both endpoint and server-authenticated account ID. Source regressions prove that forged cache scope does not affect authorization and that another account cannot take over a registered endpoint. The system deliberately does not represent push-service acceptance as confirmation that the learner saw an alert. Device permission, installed-PWA wake-up, and real provider transport remain manual acceptance boundaries.

## Canonical study-session lifecycle increment

The learning-loop audit found a source-verified integrity gap in the Study Planner. Its status chips called the generic session patch before requesting completion, enabling a skipped or rescheduled session to appear completed while the canonical completion function declined to add its evidence and downstream side effects based on the prior state. The UI now uses explicit lifecycle commands only: `startSession` for planned work and `completeSession` for in-progress work. This preserves the existing canonical side effects that mark linked plan items, add topic evidence, update applicable study goals, log activity, and award XP. Terminal/paused labels no longer behave as generic transitions. A focused page regression and learning/review regressions cover the source-controlled contract. Full release validation passed **89 Vitest files / 289 tests**, TypeScript, the source credential scan, and the production build.

## Local practice-quiz completion increment

The practice-quiz runner submits its local attempt and then reveals remediation. Before this increment, rapid repeated Finish activation could record more than one local attempt before the result state committed. A synchronous per-runner guard now makes that browser completion path idempotent for the active attempt, so connected response evidence and mastery projections are added once per finish action. Full release validation passed **90 Vitest files / 290 tests**, TypeScript, the source credential scan, and the production build. This is intentionally not represented as a trusted server assessment: the broader server-authoritative assessment/session/submission architecture remains **NOT IMPLEMENTED** and separately deferred.

## Material consent, ownership, and lifecycle source evidence

Material AI requests are protected server-side and scope the selected PDF to the authenticated workspace before a signed file URL is created. Consent is committed against the exact material/action before provider access; a revision conflict stops the request without sending the document. Server schemas bound summary and generated-question output, while the client keeps generated content as a review draft until learner confirmation creates a normal local practice quiz. Reviewed practice-question PDF export is generated locally and does not repeat provider access.

The controlled material lifecycle test covers metadata reservation, persisted workspace material reference, owned signed access, and clear-triggered metadata/quota release. Deleting Student OS metadata makes a file inaccessible through the app but does not constitute a claimed provider physical-delete guarantee. Live provider PDF handling remains manual acceptance evidence.

## Daily Lesson account-scope response isolation

Onboarding collects education level, static preset subjects, and optional custom subject labels. It does not collect country/education system or establish official curriculum provenance; the future optional catalogue migration remains **NOT IMPLEMENTED**, and custom subjects are not described as official.

Daily Lesson requests receive only the selected subject/branch/topic plus profile education level and age. The in-flight response guard now includes both the deterministic selection key and account cache scope, preventing an earlier account's personalized lesson result or error from changing a later account's active view after an account switch. A focused regression covers the correlation contract. Full release validation passed **91 Vitest files / 291 tests**, TypeScript, the source credential scan, and the production build. This is source-controlled account isolation; live authentication switching remains a manual browser acceptance scenario.

## Task dependency graph integrity increment

The Task editor now checks a proposed prerequisite list against the existing task graph before persisting it. It rejects any direct or indirect cycle that returns to the task being edited, preventing a false “blocked” state that no learner can resolve through normal task completion. The check is pure, bounded to the local canonical task graph, and does not add a second planner. Focused tests cover direct/indirect cycles and a permitted acyclic dependency. Full release validation passed **91 Vitest files / 292 tests**, TypeScript, the source credential scan, and the production build.

## Focus-session evidence audit

The Focus page records a canonical focus session only at natural focus-round completion. It carries optional task, topic, and objective links, but explicitly describes the record as effort rather than automatic task completion or proof of mastery. Pause/reset/preset changes clear the account-scoped pending focus reminder, and completion transitions to the break phase after the session is persisted. This preserves a single source of daily-goal, streak, and focus-stat evidence. Physical browser notification and installed-device delivery remain manual acceptance boundaries.

## Mastery, review, and retest source evidence

Mastery and Reviews consume the canonical deterministic learning-intelligence helpers. Topic scores expose direct quiz evidence separately from estimates and supporting recall/session signals; no time-only score is presented as mastery. The review queue derives from the same due-only spaced-repetition path used by Flashcards, while the daily recommendation uses the ranked next action rather than a parallel recommender. Learner routes return to canonical quizzes, study plans, or flashcard review. This is source-level workflow evidence; the local practice quiz remains explicitly non-authoritative pending the deferred server assessment architecture.

## Onboarding choice-state accessibility increment

The button controls used to select education level, goals, subjects, and daily capacity now expose their selected state via `aria-pressed`. This adds no country/system inference and does not relabel static or custom subject values as official curricula. A focused source regression covers every group. Full release validation passed **92 Vitest files / 293 tests**, TypeScript, the source credential scan, and the production build. Manual keyboard traversal and screen-reader announcement quality remain acceptance boundaries.

## Canonical quiz finding

`client/src/pages/Quizzes.tsx` already uses one canonical `StudyQuiz` collection, with manual and reviewed AI sources represented as metadata rather than separate persistence systems. Attempts and learning evidence are handled through the canonical store. The current runner supports question navigation and completed-attempt records, but the directive’s exact **50-question**, durable in-progress recovery, server-authoritative scoring, and detailed grade-band requirements are not yet satisfied by this local-first implementation. A migration must preserve existing quiz attempts and avoid a parallel assessment engine.

The current `scoreQuiz` helper calculates a bounded percentage from canonical question answer keys, but it executes in the client. This is suitable only for local-first provisional feedback; it does not meet the directive's requirement for server-authoritative results. Any migration must add a protected account-owned submission contract and an idempotency key, then reconcile the accepted result back into the canonical workspace rather than trusting a browser-provided score.

The protected tRPC router currently exposes AI quiz **draft** generation but no quiz-session creation, submission, or grading procedure. This confirms that server-authoritative quiz migration is architectural work, not a label change: it needs an explicit protected API and persistence/idempotency design before the UI can represent a result as trusted.

The current relational schema persists users, push state, AI rate limits, and material metadata; canonical quizzes remain in the revisioned account workspace. There is no relational quiz-session, response, or idempotency table today. Any database migration for trusted 50-question sessions must therefore be schema-first, account-scoped, and backward-compatible with existing workspace quiz history.

The shared workspace validator is strict and currently permits only basic profile subjects/level fields plus workspace-local quizzes and attempts. Country, education-system, catalogue provenance, and any draft/session recovery fields must be added to the shared type and validator together, with backward-compatible optional defaults, before they can safely survive cloud synchronization.

## Subject catalogue finding

The current onboarding experience stores selected subjects in the canonical learner profile and supports learner-entered custom subjects, but it uses a static presentation list and does not currently collect country or education-system context. This is a real directive gap. A replacement must first establish a versioned subject-catalogue model with provenance and verification status; it must not use AI-generated claims as an unverified official curriculum.

### Ghana source evidence for a future verified catalogue

The National Council for Curriculum and Assessment describes Ghana's basic-education phases and lists Standards-Based Curriculum subjects including English, Mathematics, Science, History, Creative Arts, Religious and Moral Education, Physical Education, French, Ghanaian Language, and Computing.[^nacca] Its official Standards-Based Curriculum page publishes the subject catalogue and associated curriculum resources for those foundational bands.[^subjects] The Ministry of Education curriculum microsite separately lists a broader Year 1 secondary catalogue, including Mathematics, Biology, Chemistry, Physics, Computing, Economics, Geography, Accounting, technical/vocational pathways, and languages.[^moe]

These sources support a **Ghana verified** catalogue seed only. They do not verify a universal curriculum, a learner's exact school offerings, or topic-level mappings for every level. Any additional learner-entered subject must remain marked as custom rather than official.

[^nacca]: [NaCCA — Development of the Ghanaian Curriculum](https://nacca.gov.gh/curriculum/)
[^subjects]: [NaCCA — New Standards-Based Curriculum (2019)](https://nacca.gov.gh/learning-areas-subjects/new-standards-based-curriculum-2019/)
[^moe]: [Ghana Ministry of Education — Curriculum Resources, Year 1](https://curriculumresources.edu.gh/year1/)

## Preserved security constraints

Authentication redirects must retain the existing browser-bound nonce flow. Private ownership remains derived from the authenticated server context. AI output remains a proposal or validated response; it must not directly mutate canonical learner data without the relevant review and business-rule checks.

## Manual boundaries

Real OAuth provider registration versus sign-in behavior, provider AI response quality, installed-PWA behavior, and physical mobile acceptance require live device/provider observation. They are not represented as automated proof in this document.

## Initial responsive observation

The unauthenticated landing was reviewed at a 375 × 812 viewport after the redesign. Both distinct actions remain visible, separated, readable, and full-width enough for touch use without horizontal overflow in that observed state. This does not replace a real provider login, mobile keyboard, or installed-PWA acceptance test.

## Account-isolation regression evidence

Focused regressions passed for workspace authorization, session identity binding, account-owned material access, material-summary access, and client workspace-isolation behavior. This establishes controlled coverage that one account cannot reuse another account’s protected workspace or private material route through those tested surfaces. Real browser-account switching, live OAuth, and provider-backed document processing remain manual acceptance scenarios.

## Consolidated directive reconciliation state

The available 1,409-line directive has been reconciled against the actual Student OS source in this record. The following classification keeps delivered behavior separate from source-only evidence, deferred architecture, and acceptance work that cannot be truthfully inferred from tests or code inspection.

| Directive class | Current status | Evidence and boundary |
|---|---|---|
| Auth landing and protected session boundary | **VERIFIED at source level** | Separate Create account and Log in actions preserve nonce-bound OAuth. Application requests are cookie-only; provider-side registration/sign-in choice remains manual. |
| AI inventory, context, and review gates | **VERIFIED at source level** | All model calls are protected server-side; contexts/output are bounded and structured drafts require learner review. Live provider quality remains manual. |
| Connected learning loop | **VERIFIED for canonical local-first practice** | Exams, tasks, sessions, materials, flashcards, local quizzes, topic evidence, mastery, reviews, and retest routes share canonical state/engine boundaries. |
| Security, local-first isolation, PWA, and reminders | **VERIFIED for controlled paths** | Account scoping, workspace revisions, cache exclusions, ownership checks, and durable reminder scheduling are covered. Device/provider behavior remains manual. |
| Accessibility and bundle delivery | **VERIFIED for repaired source/build contracts** | Focused interaction semantics and build chunk boundaries are covered. Real assistive technology and device performance remain manual. |
| Server-authoritative assessment | **NOT IMPLEMENTED** | Requires the separately documented relational owner-scoped session/question/response/idempotency migration. Current quiz attempts remain local practice. |
| Country/system curriculum provenance | **NOT IMPLEMENTED** | Requires the separately documented backward-compatible optional catalogue migration. Existing/custom subjects are not represented as official. |

## Deterministic learning-loop increment

The current audit traced Mastery, Reviews, Quick Add, search, reminder synchronization, and daily-context projections back to the canonical `StudyState` and deterministic `learningIntelligence` helpers. No parallel mastery, review, planning, or reminder store was introduced. One source-verified reliability defect was repaired: ranked next actions now calculate overdue task and session durations from the function's explicit planning date instead of the runtime clock. This preserves deterministic recovery and review results when a controlled date is supplied. The regression covers both task and session labels; provider/device behavior remains outside this source-controlled proof.

## Current directive verification addendum — authentication landing

The current unauthenticated application route presents two visibly distinct actions: **Create an account** for a new student and **Log in** for a returning student. Both invoke the existing event-handler-only nonce-bound `startLogin()` path; they do not create an unauthenticated local account model or weaken the cookie-only application session boundary. After authentication, `StoreProvider` is keyed by the authenticated `openId`, and startup routing waits for that account’s workspace hydration before showing onboarding or the restored workspace. The added source regression asserts both labels, both safe actions, and account-keyed provider routing. Full validation passed **180 Vitest files / 460 tests**, TypeScript, the credential-literal scan, and the production build. Actual provider registration/sign-in branching, email verification, and browser-cookie behavior remain provider/device acceptance boundaries.

## Current directive verification addendum — centralized AI route inventory

The current router confirms that every Student OS model action is a `protectedProcedure`; the server derives the allowance owner from `ctx.user.openId` before capability code runs. No browser component invokes the LLM helper directly. The durable allowance remains deliberately coarse by design: `lesson`, `assistant`, and `learning_draft` are separate account-scoped surfaces, with material summary and material practice sharing `learning_draft` parity with quiz and schedule drafts. This corrects the earlier historical wording that implied parity before the material-route repair.

| Learner capability | Protected route and durable rate-limit surface | Bounded server contract | Review or canonical-write boundary |
|---|---|---|---|
| Daily lesson generation and lesson Q&A | `dailyLessons.generate` and `.ask`; `lesson` | Validated lesson/question inputs, structured lesson output, bounded active-lesson context, timeout/fallback handling. | Answers and optional visual prompts are view artifacts; they do not mutate canonical workspace data. |
| Study Assistant | `studyAssistant.ask`; `assistant` | Validated bounded question and selectively scoped learner context; bounded completion/fallback handling. | Conversational answer remains non-canonical; optional learner feedback uses the StoreContext feedback action. |
| General AI quiz drafts | `learningDrafts.quiz`; `learning_draft` | Bounded context and strict JSON draft schema. | Learner review precedes canonical `createQuiz`; current topic validation rejects stale links. |
| AI schedule drafts | `scheduleDrafts.generate`; `learning_draft` | Bounded structured proposal plus preferred-window, capacity, recurring-block, and overlap checks. | Learner review precedes canonical session creation; rejected proposals remain recoverable. |
| Material summary draft | `studyMaterials.summary`; `learning_draft` | Selected account-owned PDF only; action-specific consent persists before signed access; summary schema bounds title, text, ideas, and questions. | Summary remains a review artifact; reviewed flashcard creation uses canonical topic/capacity admission. |
| Material practice-question draft | `studyMaterials.practiceQuestions`; `learning_draft` | Selected account-owned PDF only; action-specific consent and strict question schema. | Every question/answer/explanation requires learner confirmation before local canonical quiz creation or local PDF export. |

The inventory verifies source-controlled access, rate-limit, schema, and review boundaries. It does not claim live model quality, provider availability, content accuracy, media-generation quality, or physical-device behavior; those require provider or device acceptance observation.

## Current directive verification addendum — unified quiz and learning-loop reconciliation

Student OS currently has one **local-first practice** quiz model: manual, reviewed AI-draft, and reviewed material-draft quizzes are normalized into the same canonical `StudyQuiz` collection; attempts and optional topic learning evidence enter the same revisioned workspace through `recordQuizAttempt`. `scoreQuiz` and the answer-response builder are client-side deterministic helpers. Before persistence, each current question must have an integer answer within its current option range; missing, non-finite, fractional, and out-of-range indices reject without attempt, XP, or learning-evidence mutation. The runner only presents completion after this canonical action accepts, so a removed quiz does not produce a false local success claim.

| Directive concern | Current reconciled implementation | Status and boundary |
|---|---|---|
| One coherent practice model | `StudyQuiz`, `QuizAttempt`, and `learningEvidence` are canonical workspace collections, not separate manual/AI storage engines. | **Verified for local practice.** |
| AI-generated questions | General and material routes return bounded review drafts; learners review before `createQuiz` persists an editable canonical quiz. | **Verified at source level.** Provider quality remains manual. |
| Scoring and feedback | Browser scoring returns correct count, percent, missed IDs, reviewable responses, and recovery feedback. Current runner treats this as practice feedback. | **Not a trusted grade.** |
| Mastery/recommendation linkage | Accepted topic-linked attempts append canonical evidence consumed by the existing deterministic mastery and recommendation helpers. | **Verified for local-first learning evidence.** |
| Durable assessment/restart/retry | Current runner index and answers are React-local; no protected server session, immutable question snapshot, idempotency key, or server grading route exists. | **Not implemented; deferred schema-first assessment contract remains required.** |
| Exact long-form/proctored assessment requirements | Current workspace practice quiz bounds and browser scoring deliberately do not represent a secure high-stakes assessment. | **Not implemented; do not relabel current practice results as authoritative.** |

This reconciliation preserves one StoreContext workspace model and one deterministic learning-intelligence engine. It explicitly does not create a second quiz store or present client-generated scores as server-authoritative results.

### Implementation update — trusted timed assessment

The previously deferred trusted-assessment boundary is now implemented for a learner’s existing canonical quizzes. Protected server routes create owner-scoped immutable relational snapshots, save bounded answers, and return an idempotent server-finalized score. The new timed-assessment interface deliberately does not call `recordQuizAttempt`, so the existing local practice runner and deterministic local evidence engine remain intact. The applied migration creates `assessment_sessions`, `assessment_questions`, `assessment_responses`, and `assessment_submissions` with owner/start and owner/submit uniqueness constraints. Full validation passed **182 Vitest files / 463 tests**, TypeScript, the credential-literal scan, and the production build. This source-level proof does not replace live concurrent transaction, browser resume, keyboard, touch, or accessibility acceptance testing.

### Implementation update — optional cited catalogue provenance

The catalogue boundary is now implemented without replacing free-form profile subjects. Secondary-level onboarding offers an optional Ghana NaCCA catalogue context and exposes a narrow cited set of published secondary subject titles. Matching labels are recorded with versioned `catalogue` provenance, while every non-matching or learner-added label is recorded as `custom`; existing profiles retain their subject arrays without a forced reclassification. Strict profile and workspace validation require bounded context fields, HTTPS source URLs, and provenance keys that correspond only to current selected subjects. The seed is intentionally limited to the verified source listing and must be reviewed when NaCCA updates it.[1]

## References

[1] [National Council for Curriculum and Assessment, *Secondary Education Curriculum*](https://nacca.gov.gh/secondary-education-curriculum/)

## Current directive verification addendum — curriculum-aware catalogue reconciliation

The current onboarding source supplies broad education-level labels, a presentation-only list of twelve subject presets, and a custom-subject field. Its canonical profile persists selected subjects as `string[]`; it does **not** collect country, education-system, school curriculum, catalogue ID/version, source metadata, or subject provenance. A custom subject remains an ordinary learner-selected string and must not be represented as a verified curriculum offer. The current topic model is likewise learner-created or exam-scoped, not a curriculum catalogue.

| Directive requirement | Current source evidence | Reconciled status |
|---|---|---|
| Country and education-system context | No onboarding field or profile-schema property captures either. | **Not implemented.** |
| Official subject catalogue | Presets are user-interface choices only; no authoritative catalogue record, version, or source metadata exists. | **Not implemented.** |
| Custom-subject support | Learners can add a case-insensitive de-duplicated custom label, and it persists through the existing profile flow. | **Verified local-first behavior; not official provenance.** |
| Topic-level curriculum mapping | Canonical topics can link to subjects/exams, but have no curriculum-source identity or verification state. | **Not implemented.** |
| Safe future path | Preserve `subjects: string[]` for backward compatibility; add optional curriculum context and per-subject provenance only with schema/version compatibility transforms and cited source data. | **Deferred schema-first architecture.** |

The existing Ghana source references in this ledger are research inputs for a future narrowly scoped verified seed; they are not evidence that the live application currently supplies a Ghana curriculum catalogue. This boundary prevents an AI-generated or custom label from being mistaken for an official course offering.

## Current directive verification addendum — account, responsive, and user-flow boundaries

Controlled evidence confirms the source-level account boundary: protected server procedures derive workspace/material/reminder ownership from `ctx.user.openId`; browser cache scope is explicitly display/query partitioning rather than authorization; and the authenticated application remounts `StoreProvider` with the signed-in `openId`. Existing focused regressions cover workspace authorization, account-owned material access, client hydration isolation, Daily Lesson in-flight response isolation, and account-scoped reminder deduplication.

The unauthenticated landing was also captured at **375 × 812**. The Student OS mark, explanatory copy, Create an account action, and Log in action remained visible, distinct, and without observed horizontal overflow in that controlled viewport. This visual observation applies only to the unauthenticated landing.

| Evidence category | Controlled result | Explicit manual boundary |
|---|---|---|
| Server/account ownership | Source and regression coverage derive protected ownership from authenticated `openId`. | Real multi-account browser switching, offline conflict recovery, and multi-device merge acceptance. |
| Client isolation | Provider remount, hydration reset/persistence blocking, and stale async response guards are source-tested. | Real browser-cache inspection and device lifecycle behavior. |
| Responsive landing | One mobile-width landing capture showed distinct visible actions without observed overflow. | Authenticated workspace pages, keyboard, zoom, screen reader, touch, and installed-PWA responsiveness. |
| OAuth/provider flow | Safe nonce-bound launch and cookie-only application path are source-tested. | Provider registration/sign-in, verification email, redirects, cookies, and account recovery. |
| Notifications and AI | Source contracts cover ownership, consent, rate limits, review gates, and error handling. | Push delivery, provider response quality, device permission, and actual media generation. |
