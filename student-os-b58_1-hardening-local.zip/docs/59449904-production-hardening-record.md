# 59449904 Production Hardening Record

> **Scope and status.** This is the active evidence record for the production-hardening work that began from checkpoint `59449904`. It supersedes older reports for **current** validation, PWA, bundle, archive, and readiness claims, while preserving those records as historical evidence. The final hardening checkpoint and its release-matched archive identifier are added only after publication; they must never be guessed from this baseline.

## Source-controlled repairs

| Issue | Root cause | Repair and affected source | Why the repair holds |
|---|---|---|---|
| Nested study-plan item resurrection | `mergeStudyPlans` combined child arrays without consulting a child tombstone collection. | Added `studyPlanItems` tombstones to the state type and validation schema; nested merges now reuse the canonical `mergeById` tombstone filter. | A stale child is removed before the parent merge result is returned; the operation is deterministic and repeated application is stable. |
| Nested exam-topic resurrection | `mergeExams` had the same raw-map child merge as study plans. | Added `examTopics` tombstones and the same filtered merge rule. | A stale topic cannot reappear when either peer has a valid tombstone for its stable ID. |
| Future nested removals not consistently marked | Child deletion semantics depended on individual mutation authors remembering to add a marker. | `StoreContext` now passes every canonical mutation result through `appendRemovedNestedSyncTombstones`. | Any mutation that removes a plan item or exam topic records the corresponding tombstone before persistence/sync. Recreating work requires a new generated ID; the system never treats reuse of a deleted ID as a legitimate recreation. |
| Broken notification icons | Notification surfaces referenced non-existent root paths while assets live beneath `/icons/`. | Updated the service worker and direct browser notification helper to use `/icons/icon-192.png`; added public-asset integrity coverage. | The build and isolated production server both resolved the manifest, worker, and 192/512 icon assets with HTTP 200. |
| Service-worker shell integrity | A failed precache was silently ignored and failed navigation responses could replace the offline shell. | Rolled cache to `studentos-v8`, requires a complete shell precache, retains network-first navigation/scripts, only caches successful navigation responses, and deletes obsolete caches on activation. | A partial update does not activate over a last known-good worker; successful releases replace stale cache generations. |
| Stale public release pointers | The public deployment served `sw.js` with a four-hour cache lifetime, allowing the former v6 worker and old shell to persist after an auto-published update. | Added explicit `no-cache, must-revalidate` static-server headers for HTML and worker paths; clients register the deployable worker as `/sw.js?v=studentos-v8` with `updateViaCache: "none"`. | Browser registration carries a generation query and revalidates the worker path; the application now records the residual intermediary-cache/device-update scenario as a manual acceptance boundary rather than assuming it passed. |
| Mobile OAuth state failure | The browser was responsible for writing the `__Host-oauth_state` nonce cookie before leaving for the OAuth portal; the reported mobile callback returned `invalid oauth state`. | Added `POST /api/oauth/start`, where the server generates and sets the short-lived host-only `SameSite=Lax` cookie, and the client uses the returned nonce to build the portal state. A proxy-fragile Origin-versus-Host comparison was removed because the deployed proxy produced false mismatches; callback validation still binds both nonce and exact callback origin, and browser-readable errors redirect safely to the landing page. | Five integration regressions cover cookie attributes, proxy/mobile-compatible start behavior, nonce mismatch, redirect binding, and recovery redirect. Real provider/device completion remains manual. |
| Unresolved analytics HTML placeholders | The static HTML emitted `%VITE_ANALYTICS_*%` placeholders whenever configuration was absent/unresolved. | Removed the template tag; added optional HTTPS-only runtime script configuration in `client/src/lib/analytics.ts`. | Missing, malformed, or non-HTTPS settings omit analytics cleanly; valid settings generate an `/umami` script URL. |
| Blank-page bundle incident regression | Forced vendor chunking created an initialization-order cycle in deployed chart code. | The manual chunk graph remains absent, with `server/bundleGraph.integrity.test.ts` preventing its reintroduction. | The built production server rendered the landing UI without console errors. |

## Nested entity deletion inventory

| Entity / child collection | Identity and parent | Deletion marker | Merge rule | Evidence |
|---|---|---|---|---|
| `Task.subtasks` | Child ID inside one atomic task record | Parent `tasks` tombstone | Parent local version wins for same ID; no independent subtask merge occurs. | Existing top-level task tombstone tests. |
| `StudyPlan.items` | Stable child ID under `StudyPlan` | `studyPlanItems` | Child arrays merge by ID, then tombstone filter. | Local/server stale copy, additions, modifications, repeat merge, and serialization/hydration regressions. |
| `StudyQuiz.questions` | Child ID inside one atomic quiz record | Parent `quizzes` tombstone | Parent local version wins; questions are not independently merged. | Existing quiz ownership/validation contract coverage. |
| `QuizAttempt.responses` | Immutable response child inside one attempt | Parent `quizAttempts` tombstone | Parent atomic merge; no independent response mutation path. | Existing attempt contracts. |
| `Deck.cards` | Stable child ID under `Deck` | `cards` | Child arrays merge by ID, then tombstone filter. | Existing nested flashcard resurrection regression. |
| `Exam.topics` | Stable child ID under `Exam` | `examTopics` | Child arrays merge by ID, then tombstone filter. | Local/server stale copy, additions, modifications, repeat merge, and serialization/hydration regressions. |
| `habitLog[date]` references | Habit ID inside date-keyed log | `habits` | Date buckets union deterministically, then remove tombstoned habit IDs. | Existing idempotent deleted-habit regression. |
| Preference/profile maps and saved-lesson goals | Atomic parent fields | Parent-level lifecycle where applicable | Not independently merged; local scalar object is retained under the canonical conflict rule. | Schema and workspace privacy coverage. |

## Automated validation evidence

| Gate | Result from the current hardening worktree |
|---|---|
| Vitest | **193 files / 491 tests passed** |
| TypeScript | `pnpm run check` passed |
| Credential-literal scan | `pnpm run verify:secrets` passed |
| Production build | `pnpm run build` passed |
| Database schema/migrations | 14 migration files; new tombstones remain inside validated workspace JSON and require no relational migration |
| PWA asset build check | `manifest.webmanifest`, `sw.js`, `/icons/icon-192.png`, and `/icons/icon-512.png` present in the built public tree; the worker cache is `studentos-v8`, registration is query-versioned, local production headers for `/` and worker paths are `no-cache, must-revalidate`, and the API worker route adds `no-store` plus `Service-Worker-Allowed: /` |
| Analytics output | No `%VITE_ANALYTICS_*%` token found in `dist/public` |
| Bundle architecture | No `manualChunks` configuration; chart code remains lazy-loaded, and the built entry/runtime smoke did not reproduce a bootstrap error |

The current build still reports one 801,257-byte unminified JavaScript asset. This is recorded as a **performance observation**, not concealed or addressed with a fragile forced vendor split. Route modules, chart rendering, PDF export, and dashboard components remain separate build assets; field performance requires device/network testing.

## Runtime and deployment evidence

The current hardening worktree was built and served through an isolated production process. A browser rendered the unauthenticated Student OS landing interface, populated the root element, and reported no console output. The manifest, service worker, and notification icon assets each returned HTTP 200. The non-static API worker route is source-controlled with an explicit root scope and no-store policy. The public deployment rendered its unauthenticated interface after propagation; its worker endpoint also returned JavaScript with the v8 payload and root-scope authorization. The pre-repair public OAuth start endpoint returned an unexpected 403 Origin response under the proxy; the corrected route is pending its own post-publish endpoint check. The reported mobile OAuth provider flow remains a real-device/provider manual acceptance boundary. These are genuine bootstrap checks, but they are **not** authenticated-user, physical-device, or end-to-end provider acceptance results.

## Required manual acceptance matrix

| Area | Required test | Status |
|---|---|---|
| Authentication | Real OAuth sign-in, logout, second-account login, and account switching | **NOT EXECUTED — MANUAL DEVICE/PROVIDER VALIDATION REQUIRED** |
| Workspace | Authenticated restore plus create/edit/delete behavior | **NOT EXECUTED — MANUAL DEVICE/PROVIDER VALIDATION REQUIRED** |
| Offline synchronization | Offline create/edit/delete, restart during pending sync, stale-device conflict, and cross-device tombstone acceptance | **NOT EXECUTED — MANUAL DEVICE/PROVIDER VALIDATION REQUIRED** |
| PWA | Install, offline launch, update from an existing worker/cache, and post-deployment update | **NOT EXECUTED — MANUAL DEVICE/PROVIDER VALIDATION REQUIRED** |
| Push | Permission, device registration, delivery, icon/badge appearance, and notification-click routing | **NOT EXECUTED — MANUAL DEVICE/PROVIDER VALIDATION REQUIRED** |
| AI | Authenticated provider request, rate limit, failure handling, and answer rendering | **NOT EXECUTED — MANUAL DEVICE/PROVIDER VALIDATION REQUIRED** |
| Accessibility | Authenticated keyboard flow, screen-reader basics, zoom/reflow, focus management, and touch interaction | **NOT EXECUTED — MANUAL DEVICE/PROVIDER VALIDATION REQUIRED** |

## Historical-document handling

The prior `final-evidence-led-hardening-status.md`, `competitive-product-upgrade-reconciliation.md`, and `production-excellence-final-report.md` now carry explicit historical/supersession notices. Their older counts and release identifiers remain preserved as past evidence and are not rewritten as current facts.
