# Authenticated-Flow Responsive and Boundary Validation Matrix

This record closes the evidence classification gap for responsive and local-first validation. It does **not** claim that an authenticated browser or physical device was operated where no authenticated provider session was available.

| Protected flow | Controlled source/build evidence | Classification | Required manual acceptance |
|---|---|---|---|
| Auth-to-workspace boot | `App.tsx` mounts account-keyed `StoreProvider` only after auth resolution; account-switch hydration and workspace restore regressions passed. | **Source-verified.** | Sign in as two separate users, refresh, expire one session, and confirm neither browser sees the other workspace. |
| Dashboard and Today | Responsive shell and canonical ranked-action handoffs are source-tested; lazy route build output is verified. | **Source-verified contracts.** | At 320px, standard Android width, large mobile, and desktop, confirm cards, action controls, scrolling, bottom navigation, and visible focus states. |
| Study Planner and Focus | Canonical session admission, recurring-block avoidance, lifecycle commands, and Focus task/topic handoffs are source-tested. | **Source-verified contracts.** | On a device, create/edit/start/complete/reschedule sessions and verify no clipped dialogs, hidden controls, or keyboard collisions. |
| Practice and trusted assessments | Local practice acceptance, server grade semantics, opaque trusted-session restore, and saved-answer contracts are tested. | **Source-verified contracts.** | Start a timed assessment, answer questions, refresh, reopen in the same browser tab session, submit twice, then check the grade and accessibility of options/results. |
| Materials and reviewed AI artifacts | Protected ownership, consent, material draft binding, flashcard admission, and quiz-review routes are tested. | **Source-verified contracts.** | Upload supported/invalid documents, use summary/practice actions, rotate device or resize narrow browser, and check loading/error/retry states. |
| Settings, notifications, and profile | Strict settings/profile validation, push endpoint ownership, reminder queue replacement, and account-scoped history tests are present. | **Source-verified contracts.** | Verify touch targets, permission prompt, notification receipt/disablement, photo picker, vibration controls, zoom, and screen-reader announcements. |
| Local-first/offline reconciliation | Workspace hydration, isolation, revision merge, tombstones, cache privacy, and a fresh 14-file/61-test account/local-first subset passed. | **Source-verified contracts.** | Disconnect network after an edit, close/reopen, reconnect, and confirm exactly one safe merge without stale-account data. |
| Public auth landing | Controlled 375 × 812 capture showed distinct account actions with no observed horizontal overflow. | **Controlled visual observation.** | Complete the provider redirect on actual mobile and desktop browsers; verify loading, errors, and keyboard/tab flow. |
| Build and bundle impact | Full production build passed; largest JavaScript asset is 428.14 kB and all major product routes remain lazy-loaded. | **Build-verified.** | Measure route loading, CPU/memory, and interaction responsiveness on representative lower-end Android hardware. |

## Manual result recording template

For each manual run, record device/browser/version, account profile, network state, viewport, flow, observed result, timestamp, and any screenshot or console reference. A failed result should remain a defect report rather than be converted into a source-only pass.
