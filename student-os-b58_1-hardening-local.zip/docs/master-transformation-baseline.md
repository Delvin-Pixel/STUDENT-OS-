# Student OS — Production-Excellence Transformation Baseline

This baseline is a new source-verified assessment for the uploaded production-excellence specification. It supersedes no prior evidence record; it records what the current code actually supports, what was repaired during this mission, and what still requires implementation or physical-device evidence.

## Verified architecture map

Student OS is a React/TypeScript PWA with a single canonical `StudyState` in `StoreContext`, account-scoped local persistence, revisioned workspace serialization through protected tRPC procedures, a Drizzle/TiDB data layer for identity and push infrastructure, S3-backed protected private assets, and an authenticated service-worker push channel. Deterministic learning intelligence is centralized in `learningIntelligence`; no second planner, mastery store, or reminder planner should be introduced.

| System area | Current verified design | Material strengths | Current transformation concern |
| --- | --- | --- | --- |
| Identity and session | OAuth session cookie or preview bearer fallback, resolved server-side to a database user | Protected procedures derive ownership from `ctx.user`; cache scopes are non-authoritative | Session secret validation was previously permissive; this mission now rejects blank or under-32-byte secrets |
| Canonical workspace | Local-first account-scoped `StudyState`, protected server blob, revision conflict return, client merge | Tombstones make delete-vs-edit deterministic; device-private ratings are projected out of cloud state | The JSON blob remains a bounded 4 MiB bridge, not a normalized long-term learning database |
| Learning loop | Topics, evidence, sessions, plans, quizzes, flashcards, exam topics, mastery/review/ranking logic | Existing model connects much of the requested academic loop and records completed-session/quiz/review signals | Tasks and Focus are not yet rich enough for the master specification’s dependencies, subtasks, partial work, replacement, or objective linkage |
| AI | Protected/rate-limited lesson, assistant, quiz-draft, and material-summary calls through shared Forge transport | Structured validation and local fallbacks protect workspace data when providers fail | Recurrent observed Daily Lesson provider timeouts, no request IDs, and incomplete learner-facing retry diagnostics need a dedicated reliability pass |
| Private storage | Account-prefixed material and photo keys, protected signed resolvers, raw proxy blocks private path classes | Direct Account A/B and raw-path coverage exists | Upload/processing journey needs a fuller resource-to-practice-to-feedback flow |
| Push and reminders | Ownership-bound opaque endpoint, durable reminders and delivery history, Heartbeat dispatch, service-worker display | Endpoint race protection, retry/retirement, same-origin navigation, quiet hours and caps are present | Live duplicate reminders were discovered and cleaned; unique device/dedupe enforcement and one-minute manual-test cooldown are now applied |
| Database | `users` workspace blob plus push device/reminder/history/schedule tables | Unique account endpoint and new reminder dedupe constraints protect key invariants | Most learning records remain inside the workspace blob; normalization remains a scale migration, not a completed capability |
| UX and performance | Responsive shell, lazy specialist routes, deferred dashboard, lightweight safe AI renderer | Earlier evidence reduced main JS and removed a 938.62 kB chat asset | Every major journey and dense mobile flow still needs a fresh visual/accessibility pass under the new specification |

## Confirmed findings repaired in this mission so far

| Priority | Finding | Evidence | Remediation | Verification |
| --- | --- | --- | --- | --- |
| P0 | Empty or weak session secret could sign/verify authentication tokens | Session SDK encoded `ENV.cookieSecret` without a guard | Added 32-byte fail-closed validation | Unit regression and TypeScript validation |
| P0 | Shared LLM layer reported the wrong credential and surfaced full upstream response text | Shared LLM transport source inspection | Added blank-key rejection and bounded safe upstream errors | Unit regression, lesson/assistant tests, TypeScript validation |
| P0 | Source archive could include ignored but secret-bearing `.project-config.json` | Non-disclosing metadata audit showed populated secret fields; old archive policy did not exclude it | Added verified archive script and explicit project-config exclusion | Disposable archive integrity and excluded-path check |
| P1 | OAuth diagnostic script printed full `Set-Cookie`, redirect, and body values | Source quality scan | Redacted output to presence/length metadata | Static output-pattern check |
| P1 | Live push reminder table contained 28 duplicate `(deviceId, dedupeKey)` groups | Direct database aggregate query | Remapped delivery history, removed 56 duplicate rows, added unique constraint and in-process plan dedupe | Post-migration aggregate showed zero groups; unique index verified |
| P1 | Immediate push connection test could be repeatedly invoked | Protected router inspection | Added durable atomic per-device one-minute cooldown with a nullable migration field | Unit boundary test, owner tests, live schema verification |

## Confirmed gaps to drive the next phases

The master specification requires depth rather than disconnected pages. The next implementation phases must prioritize a **connected execution loop**: richer task state and recovery, Focus-to-topic/task evidence, planner inputs from schedules and real completion behavior, and reliable user-visible AI fallback/retry behavior. Quiz assessment must progress beyond its present compact multiple-choice/true-false result model, while materials must become a consented resource pipeline rather than only a secure upload plus summary.

The following boundaries remain explicit: provider delivery, real OAuth account switching, installed-PWA notification display, native vibration behavior, and external model availability require manual-device or live-provider validation. This baseline is therefore not a production certification.
