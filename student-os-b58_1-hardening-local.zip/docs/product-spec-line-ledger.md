# Product Specification Line Ledger

This generated ledger accounts for all 833 lines in `/home/ubuntu/upload/pasted_content.txt`. Its interpretation links to the evidence and manual-boundary matrix in `docs/final-evidence-led-hardening-status.md`; it does **not** claim an illustrative example is a separate mandatory engine. Rebuild with `node scripts/generate-product-spec-line-ledger.mjs`.

| Source line | Source text | Reconciled section | Evidence disposition |
|---:|---|---|---|
| 1 | 🚀 STUDENT OS — COMPETITIVE FEATURE & PRODUCT UPGRADE MASTER PROMPT | Preamble / product context | Product context captured by the section matrix |
| 2 | Use this as a product-improvement specification for the existing Student OS. | Preamble / product context | Product context captured by the section matrix |
| 3 | Do NOT blindly copy other applications. | Preamble / product context | Product context captured by the section matrix |
| 4 | Instead, study the strengths of leading student applications and incorporate the underlying product principles into Student OS while maintaining Student OS's own identity. | Preamble / product context | Product context captured by the section matrix |
| 5 | The objective is: | Preamble / product context | Product context captured by the section matrix |
| 6 | Make Student OS a genuine digital operating system for a student's academic life — not merely a task manager with a few education features. | Preamble / product context | Product context captured by the section matrix |
| 7 | Current leading student apps demonstrate strong specialization: | Preamble / product context | Product context captured by the section matrix |
| 8 | Anki → exceptional spaced-repetition learning | Preamble / product context | Product context captured by the section matrix |
| 9 | Quizlet → accessible flashcards, shared study material and engaging study modes | Preamble / product context | Product context captured by the section matrix |
| 10 | Notion → flexible organization and workspace customization | Preamble / product context | Product context captured by the section matrix |
| 11 | StudySmarter → revision planning + flashcards + quizzes + study materials + AI | Preamble / product context | Product context captured by the section matrix |
| 12 | Fennie → connects coursework, notes, PDFs, study plans, flashcards and quizzes into one learning workflow | Preamble / product context | Product context captured by the section matrix |
| 13 | Goodnotes/OneNote → strong digital study-material/notes experience | Preamble / product context | Product context captured by the section matrix |
| 14 | Focus apps → make concentration measurable and engaging | Preamble / product context | Product context captured by the section matrix |
| 15 | StudySmarter currently advertises 10M+ Play Store downloads and combines personalized study plans, AI-generated materials, flashcards, quizzes, notes and shared study resources. � | Preamble / product context | Product context captured by the section matrix |
| 16 | Google Play +1 | Preamble / product context | Product context captured by the section matrix |
| 17 | Fennie's current Play Store description similarly connects classes, syllabi, daily plans, notes, PDFs, AI-generated flashcards, spaced repetition, quizzes and calendar information. � | Preamble / product context | Product context captured by the section matrix |
| 18 | Google Play | Preamble / product context | Product context captured by the section matrix |
| 19 | Student OS should take the best ideas from these categories and integrate them into a coherent system. | Preamble / product context | Product context captured by the section matrix |
| 20 | 1. THE CORE PRODUCT VISION | 1 — Core daily questions | Command center, connected workspace, and deterministic learning intelligence |
| 21 | Student OS should answer five questions every day: | 1 — Core daily questions | Command center, connected workspace, and deterministic learning intelligence |
| 22 | 1. What do I need to do? | 1 — Core daily questions | Command center, connected workspace, and deterministic learning intelligence |
| 23 | Tasks, assignments, deadlines, exams. | 1 — Core daily questions | Command center, connected workspace, and deterministic learning intelligence |
| 24 | 2. What should I study? | 1 — Core daily questions | Command center, connected workspace, and deterministic learning intelligence |
| 25 | Personalized study recommendations based on: | 1 — Core daily questions | Command center, connected workspace, and deterministic learning intelligence |
| 26 | upcoming exams | 1 — Core daily questions | Command center, connected workspace, and deterministic learning intelligence |
| 27 | weak subjects | 1 — Core daily questions | Command center, connected workspace, and deterministic learning intelligence |
| 28 | overdue work | 1 — Core daily questions | Command center, connected workspace, and deterministic learning intelligence |
| 29 | available time | 1 — Core daily questions | Command center, connected workspace, and deterministic learning intelligence |
| 30 | study history | 1 — Core daily questions | Command center, connected workspace, and deterministic learning intelligence |
| 31 | timetable | 1 — Core daily questions | Command center, connected workspace, and deterministic learning intelligence |
| 32 | goals | 1 — Core daily questions | Command center, connected workspace, and deterministic learning intelligence |
| 33 | 3. How should I study it? | 1 — Core daily questions | Command center, connected workspace, and deterministic learning intelligence |
| 34 | Provide appropriate tools: | 1 — Core daily questions | Command center, connected workspace, and deterministic learning intelligence |
| 35 | notes | 1 — Core daily questions | Command center, connected workspace, and deterministic learning intelligence |
| 36 | flashcards | 1 — Core daily questions | Command center, connected workspace, and deterministic learning intelligence |
| 37 | quizzes | 1 — Core daily questions | Command center, connected workspace, and deterministic learning intelligence |
| 38 | active recall | 1 — Core daily questions | Command center, connected workspace, and deterministic learning intelligence |
| 39 | spaced repetition | 1 — Core daily questions | Command center, connected workspace, and deterministic learning intelligence |
| 40 | focused study sessions | 1 — Core daily questions | Command center, connected workspace, and deterministic learning intelligence |
| 41 | AI explanations | 1 — Core daily questions | Command center, connected workspace, and deterministic learning intelligence |
| 42 | practice questions | 1 — Core daily questions | Command center, connected workspace, and deterministic learning intelligence |
| 43 | 4. Am I actually improving? | 1 — Core daily questions | Command center, connected workspace, and deterministic learning intelligence |
| 44 | Show: | 1 — Core daily questions | Command center, connected workspace, and deterministic learning intelligence |
| 45 | study consistency | 1 — Core daily questions | Command center, connected workspace, and deterministic learning intelligence |
| 46 | subject progress | 1 — Core daily questions | Command center, connected workspace, and deterministic learning intelligence |
| 47 | exam preparation | 1 — Core daily questions | Command center, connected workspace, and deterministic learning intelligence |
| 48 | retention | 1 — Core daily questions | Command center, connected workspace, and deterministic learning intelligence |
| 49 | completed work | 1 — Core daily questions | Command center, connected workspace, and deterministic learning intelligence |
| 50 | goals | 1 — Core daily questions | Command center, connected workspace, and deterministic learning intelligence |
| 51 | habits | 1 — Core daily questions | Command center, connected workspace, and deterministic learning intelligence |
| 52 | 5. What should I do next? | 1 — Core daily questions | Command center, connected workspace, and deterministic learning intelligence |
| 53 | This is the most important question. | 1 — Core daily questions | Command center, connected workspace, and deterministic learning intelligence |
| 54 | Student OS should continuously guide the student toward the next useful action. | 1 — Core daily questions | Command center, connected workspace, and deterministic learning intelligence |
| 55 | 2. CHANGE THE DASHBOARD FROM A STATIC HOME PAGE INTO A COMMAND CENTER | 2 — Command center | Dashboard and ranked next actions |
| 56 | The dashboard should not simply display information. | 2 — Command center | Dashboard and ranked next actions |
| 57 | It should help the student act. | 2 — Command center | Dashboard and ranked next actions |
| 58 | Instead of: | 2 — Command center | Dashboard and ranked next actions |
| 59 | "You have 8 tasks." | 2 — Command center | Dashboard and ranked next actions |
| 60 | prefer: | 2 — Command center | Dashboard and ranked next actions |
| 61 | Good evening, Delvin. | 2 — Command center | Dashboard and ranked next actions |
| 62 | You have 2 assignments due tomorrow and Physics revision is currently your weakest exam area. | 2 — Command center | Dashboard and ranked next actions |
| 63 | Recommended next step: | 2 — Command center | Dashboard and ranked next actions |
| 64 | 🧠 35 min Physics revision | 2 — Command center | Dashboard and ranked next actions |
| 65 | 📚 Topic: Electromagnetic Induction | 2 — Command center | Dashboard and ranked next actions |
| 66 | 🎯 Exam: 6 days away | 2 — Command center | Dashboard and ranked next actions |
| 67 | Then: | 2 — Command center | Dashboard and ranked next actions |
| 68 | [Start Session] | 2 — Command center | Dashboard and ranked next actions |
| 69 | The dashboard should intelligently prioritize what matters. | 2 — Command center | Dashboard and ranked next actions |
| 70 | 3. ADD "TODAY'S PLAN" | 3 — Today plan | Daily context and timetable/task/exam capacity |
| 71 | Create a prominent daily plan. | 3 — Today plan | Daily context and timetable/task/exam capacity |
| 72 | Example: | 3 — Today plan | Daily context and timetable/task/exam capacity |
| 73 | TODAY | 3 — Today plan | Daily context and timetable/task/exam capacity |
| 74 | — | 3 — Today plan | Daily context and timetable/task/exam capacity |
| 75 | 08:00 — Mathematics class | 3 — Today plan | Daily context and timetable/task/exam capacity |
| 76 | 10:00 — Physics class | 3 — Today plan | Daily context and timetable/task/exam capacity |
| 77 | — | 3 — Today plan | Daily context and timetable/task/exam capacity |
| 78 | 16:30 | 3 — Today plan | Daily context and timetable/task/exam capacity |
| 79 | 📝 Complete Chemistry assignment | 3 — Today plan | Daily context and timetable/task/exam capacity |
| 80 | 25 min | 3 — Today plan | Daily context and timetable/task/exam capacity |
| 81 | — | 3 — Today plan | Daily context and timetable/task/exam capacity |
| 82 | 18:00 | 3 — Today plan | Daily context and timetable/task/exam capacity |
| 83 | 🧠 Physics revision | 3 — Today plan | Daily context and timetable/task/exam capacity |
| 84 | 40 min | 3 — Today plan | Daily context and timetable/task/exam capacity |
| 85 | — | 3 — Today plan | Daily context and timetable/task/exam capacity |
| 86 | 19:00 | 3 — Today plan | Daily context and timetable/task/exam capacity |
| 87 | 🃏 Flashcard review | 3 — Today plan | Daily context and timetable/task/exam capacity |
| 88 | 15 min | 3 — Today plan | Daily context and timetable/task/exam capacity |
| 89 | — | 3 — Today plan | Daily context and timetable/task/exam capacity |
| 90 | 20:00 | 3 — Today plan | Daily context and timetable/task/exam capacity |
| 91 | 📚 Review today's notes | 3 — Today plan | Daily context and timetable/task/exam capacity |
| 92 | 20 min | 3 — Today plan | Daily context and timetable/task/exam capacity |
| 93 | The plan should adapt based on: | 3 — Today plan | Daily context and timetable/task/exam capacity |
| 94 | timetable | 3 — Today plan | Daily context and timetable/task/exam capacity |
| 95 | tasks | 3 — Today plan | Daily context and timetable/task/exam capacity |
| 96 | deadlines | 3 — Today plan | Daily context and timetable/task/exam capacity |
| 97 | exams | 3 — Today plan | Daily context and timetable/task/exam capacity |
| 98 | available time | 3 — Today plan | Daily context and timetable/task/exam capacity |
| 99 | student goals | 3 — Today plan | Daily context and timetable/task/exam capacity |
| 100 | 4. CREATE AN INTELLIGENT STUDY PLANNER | 4 — Study planner | Canonical revision plans and capacity-safe recovery |
| 101 | This should become one of Student OS's flagship features. | 4 — Study planner | Canonical revision plans and capacity-safe recovery |
| 102 | Student enters: | 4 — Study planner | Canonical revision plans and capacity-safe recovery |
| 103 | Exam: | 4 — Study planner | Canonical revision plans and capacity-safe recovery |
| 104 | Physics | 4 — Study planner | Canonical revision plans and capacity-safe recovery |
| 105 | — | 4 — Study planner | Canonical revision plans and capacity-safe recovery |
| 106 | Date: | 4 — Study planner | Canonical revision plans and capacity-safe recovery |
| 107 | September 20 | 4 — Study planner | Canonical revision plans and capacity-safe recovery |
| 108 | — | 4 — Study planner | Canonical revision plans and capacity-safe recovery |
| 109 | Topics: | 4 — Study planner | Canonical revision plans and capacity-safe recovery |
| 110 | Mechanics | 4 — Study planner | Canonical revision plans and capacity-safe recovery |
| 111 | Waves | 4 — Study planner | Canonical revision plans and capacity-safe recovery |
| 112 | Electricity | 4 — Study planner | Canonical revision plans and capacity-safe recovery |
| 113 | Magnetism | 4 — Study planner | Canonical revision plans and capacity-safe recovery |
| 114 | Student OS generates a reasonable revision schedule. | 4 — Study planner | Canonical revision plans and capacity-safe recovery |
| 115 | Example: | 4 — Study planner | Canonical revision plans and capacity-safe recovery |
| 116 | MON | 4 — Study planner | Canonical revision plans and capacity-safe recovery |
| 117 | Mechanics — 45 min | 4 — Study planner | Canonical revision plans and capacity-safe recovery |
| 118 | — | 4 — Study planner | Canonical revision plans and capacity-safe recovery |
| 119 | TUE | 4 — Study planner | Canonical revision plans and capacity-safe recovery |
| 120 | Waves — 45 min | 4 — Study planner | Canonical revision plans and capacity-safe recovery |
| 121 | — | 4 — Study planner | Canonical revision plans and capacity-safe recovery |
| 122 | WED | 4 — Study planner | Canonical revision plans and capacity-safe recovery |
| 123 | Electricity — 45 min | 4 — Study planner | Canonical revision plans and capacity-safe recovery |
| 124 | — | 4 — Study planner | Canonical revision plans and capacity-safe recovery |
| 125 | THU | 4 — Study planner | Canonical revision plans and capacity-safe recovery |
| 126 | Mechanics practice — 30 min | 4 — Study planner | Canonical revision plans and capacity-safe recovery |
| 127 | — | 4 — Study planner | Canonical revision plans and capacity-safe recovery |
| 128 | FRI | 4 — Study planner | Canonical revision plans and capacity-safe recovery |
| 129 | Magnetism — 45 min | 4 — Study planner | Canonical revision plans and capacity-safe recovery |
| 130 | — | 4 — Study planner | Canonical revision plans and capacity-safe recovery |
| 131 | SAT | 4 — Study planner | Canonical revision plans and capacity-safe recovery |
| 132 | Mixed practice — 60 min | 4 — Study planner | Canonical revision plans and capacity-safe recovery |
| 133 | — | 4 — Study planner | Canonical revision plans and capacity-safe recovery |
| 134 | SUN | 4 — Study planner | Canonical revision plans and capacity-safe recovery |
| 135 | Weak-topic review | 4 — Study planner | Canonical revision plans and capacity-safe recovery |
| 136 | The plan must adjust if the student misses a session. | 4 — Study planner | Canonical revision plans and capacity-safe recovery |
| 137 | Do NOT simply move everything one day forward and create an impossible backlog. | 4 — Study planner | Canonical revision plans and capacity-safe recovery |
| 138 | Recalculate intelligently. | 4 — Study planner | Canonical revision plans and capacity-safe recovery |
| 139 | 5. CONNECT EXAMS TO EVERYTHING | 5 — Connected exams | Exam-topic links across learning artifacts |
| 140 | An exam should not be an isolated calendar item. | 5 — Connected exams | Exam-topic links across learning artifacts |
| 141 | When a student creates: | 5 — Connected exams | Exam-topic links across learning artifacts |
| 142 | Physics Exam — September 20 | 5 — Connected exams | Exam-topic links across learning artifacts |
| 143 | Student OS should potentially connect it to: | 5 — Connected exams | Exam-topic links across learning artifacts |
| 144 | study plan | 5 — Connected exams | Exam-topic links across learning artifacts |
| 145 | topics | 5 — Connected exams | Exam-topic links across learning artifacts |
| 146 | flashcards | 5 — Connected exams | Exam-topic links across learning artifacts |
| 147 | quizzes | 5 — Connected exams | Exam-topic links across learning artifacts |
| 148 | timetable | 5 — Connected exams | Exam-topic links across learning artifacts |
| 149 | reminders | 5 — Connected exams | Exam-topic links across learning artifacts |
| 150 | focus sessions | 5 — Connected exams | Exam-topic links across learning artifacts |
| 151 | progress analytics | 5 — Connected exams | Exam-topic links across learning artifacts |
| 152 | The exam becomes a learning objective. | 5 — Connected exams | Exam-topic links across learning artifacts |
| 153 | 6. BUILD A REAL LEARNING LOOP | 6 — Learning loop | Practice, evidence, review, retest, mastery |
| 154 | The central Student OS loop should be: | 6 — Learning loop | Practice, evidence, review, retest, mastery |
| 155 | LEARN | 6 — Learning loop | Practice, evidence, review, retest, mastery |
| 156 | ↓ | 6 — Learning loop | Practice, evidence, review, retest, mastery |
| 157 | PRACTICE | 6 — Learning loop | Practice, evidence, review, retest, mastery |
| 158 | ↓ | 6 — Learning loop | Practice, evidence, review, retest, mastery |
| 159 | TEST | 6 — Learning loop | Practice, evidence, review, retest, mastery |
| 160 | ↓ | 6 — Learning loop | Practice, evidence, review, retest, mastery |
| 161 | IDENTIFY WEAKNESS | 6 — Learning loop | Practice, evidence, review, retest, mastery |
| 162 | ↓ | 6 — Learning loop | Practice, evidence, review, retest, mastery |
| 163 | REVIEW | 6 — Learning loop | Practice, evidence, review, retest, mastery |
| 164 | ↓ | 6 — Learning loop | Practice, evidence, review, retest, mastery |
| 165 | RETEST | 6 — Learning loop | Practice, evidence, review, retest, mastery |
| 166 | ↓ | 6 — Learning loop | Practice, evidence, review, retest, mastery |
| 167 | IMPROVE | 6 — Learning loop | Practice, evidence, review, retest, mastery |
| 168 | Everything should feed into this loop. | 6 — Learning loop | Practice, evidence, review, retest, mastery |
| 169 | 7. UPGRADE FLASHCARDS | 7 — Spaced repetition | Canonical four-grade flashcard scheduling |
| 170 | Do not stop at simple front/back flashcards. | 7 — Spaced repetition | Canonical four-grade flashcard scheduling |
| 171 | Implement proper spaced repetition. | 7 — Spaced repetition | Canonical four-grade flashcard scheduling |
| 172 | Each card should track: | 7 — Spaced repetition | Canonical four-grade flashcard scheduling |
| 173 | creation date | 7 — Spaced repetition | Canonical four-grade flashcard scheduling |
| 174 | review count | 7 — Spaced repetition | Canonical four-grade flashcard scheduling |
| 175 | last review | 7 — Spaced repetition | Canonical four-grade flashcard scheduling |
| 176 | next review | 7 — Spaced repetition | Canonical four-grade flashcard scheduling |
| 177 | difficulty | 7 — Spaced repetition | Canonical four-grade flashcard scheduling |
| 178 | performance | 7 — Spaced repetition | Canonical four-grade flashcard scheduling |
| 179 | retention estimate | 7 — Spaced repetition | Canonical four-grade flashcard scheduling |
| 180 | Use review choices such as: | 7 — Spaced repetition | Canonical four-grade flashcard scheduling |
| 181 | Again | 7 — Spaced repetition | Canonical four-grade flashcard scheduling |
| 182 | Hard | 7 — Spaced repetition | Canonical four-grade flashcard scheduling |
| 183 | Good | 7 — Spaced repetition | Canonical four-grade flashcard scheduling |
| 184 | Easy | 7 — Spaced repetition | Canonical four-grade flashcard scheduling |
| 185 | The algorithm should determine when the card returns. | 7 — Spaced repetition | Canonical four-grade flashcard scheduling |
| 186 | The purpose is: | 7 — Spaced repetition | Canonical four-grade flashcard scheduling |
| 187 | Show the student material shortly before they are likely to forget it. | 7 — Spaced repetition | Canonical four-grade flashcard scheduling |
| 188 | Do not make spaced repetition merely cosmetic. | 7 — Spaced repetition | Canonical four-grade flashcard scheduling |
| 189 | Anki remains widely regarded as a benchmark for serious long-term memorization, so Student OS should learn from its underlying methodology while providing a much friendlier interface. � | 7 — Spaced repetition | Canonical four-grade flashcard scheduling |
| 190 | BestForAndroid | 7 — Spaced repetition | Canonical four-grade flashcard scheduling |
| 191 | 8. GENERATE FLASHCARDS FROM STUDENT MATERIAL | 8 — Generated flashcards | Consent, bounded drafts, learner review |
| 192 | Allow: | 8 — Generated flashcards | Consent, bounded drafts, learner review |
| 193 | PDF | 8 — Generated flashcards | Consent, bounded drafts, learner review |
| 194 | ↓ | 8 — Generated flashcards | Consent, bounded drafts, learner review |
| 195 | AI | 8 — Generated flashcards | Consent, bounded drafts, learner review |
| 196 | ↓ | 8 — Generated flashcards | Consent, bounded drafts, learner review |
| 197 | Flashcards | 8 — Generated flashcards | Consent, bounded drafts, learner review |
| 198 | and: | 8 — Generated flashcards | Consent, bounded drafts, learner review |
| 199 | Notes | 8 — Generated flashcards | Consent, bounded drafts, learner review |
| 200 | ↓ | 8 — Generated flashcards | Consent, bounded drafts, learner review |
| 201 | AI | 8 — Generated flashcards | Consent, bounded drafts, learner review |
| 202 | ↓ | 8 — Generated flashcards | Consent, bounded drafts, learner review |
| 203 | Flashcards | 8 — Generated flashcards | Consent, bounded drafts, learner review |
| 204 | and: | 8 — Generated flashcards | Consent, bounded drafts, learner review |
| 205 | Topic | 8 — Generated flashcards | Consent, bounded drafts, learner review |
| 206 | ↓ | 8 — Generated flashcards | Consent, bounded drafts, learner review |
| 207 | AI | 8 — Generated flashcards | Consent, bounded drafts, learner review |
| 208 | ↓ | 8 — Generated flashcards | Consent, bounded drafts, learner review |
| 209 | Flashcards | 8 — Generated flashcards | Consent, bounded drafts, learner review |
| 210 | But ALWAYS let the student review/edit generated cards before saving them. | 8 — Generated flashcards | Consent, bounded drafts, learner review |
| 211 | AI-generated educational content must not automatically become trusted truth. | 8 — Generated flashcards | Consent, bounded drafts, learner review |
| 212 | 9. ADD AI-GENERATED QUIZZES | 9 — AI quizzes | Reviewed quiz drafts and canonical practice |
| 213 | Student selects: | 9 — AI quizzes | Reviewed quiz drafts and canonical practice |
| 214 | Physics → Waves | 9 — AI quizzes | Reviewed quiz drafts and canonical practice |
| 215 | Student OS generates: | 9 — AI quizzes | Reviewed quiz drafts and canonical practice |
| 216 | multiple choice | 9 — AI quizzes | Reviewed quiz drafts and canonical practice |
| 217 | true/false | 9 — AI quizzes | Reviewed quiz drafts and canonical practice |
| 218 | short answer | 9 — AI quizzes | Reviewed quiz drafts and canonical practice |
| 219 | conceptual questions | 9 — AI quizzes | Reviewed quiz drafts and canonical practice |
| 220 | calculation/practice questions where appropriate | 9 — AI quizzes | Reviewed quiz drafts and canonical practice |
| 221 | After the quiz: | 9 — AI quizzes | Reviewed quiz drafts and canonical practice |
| 222 | Score: 72% | 9 — AI quizzes | Reviewed quiz drafts and canonical practice |
| 223 | — | 9 — AI quizzes | Reviewed quiz drafts and canonical practice |
| 224 | Strong: | 9 — AI quizzes | Reviewed quiz drafts and canonical practice |
| 225 | ✓ Basic wave properties | 9 — AI quizzes | Reviewed quiz drafts and canonical practice |
| 226 | — | 9 — AI quizzes | Reviewed quiz drafts and canonical practice |
| 227 | Needs work: | 9 — AI quizzes | Reviewed quiz drafts and canonical practice |
| 228 | ⚠ Standing waves | 9 — AI quizzes | Reviewed quiz drafts and canonical practice |
| 229 | ⚠ Phase difference | 9 — AI quizzes | Reviewed quiz drafts and canonical practice |
| 230 | Then: | 9 — AI quizzes | Reviewed quiz drafts and canonical practice |
| 231 | Review weak topics | 9 — AI quizzes | Reviewed quiz drafts and canonical practice |
| 232 | This creates a complete learning loop. | 9 — AI quizzes | Reviewed quiz drafts and canonical practice |
| 233 | 10. QUIZ RESULTS MUST FEED THE STUDY PLAN | 10 — Quiz actionability | Evidence-driven priority and remediation |
| 234 | This is extremely important. | 10 — Quiz actionability | Evidence-driven priority and remediation |
| 235 | If a student repeatedly performs poorly on: | 10 — Quiz actionability | Evidence-driven priority and remediation |
| 236 | Kirchhoff's Laws | 10 — Quiz actionability | Evidence-driven priority and remediation |
| 237 | Student OS should increase its priority. | 10 — Quiz actionability | Evidence-driven priority and remediation |
| 238 | For example: | 10 — Quiz actionability | Evidence-driven priority and remediation |
| 239 | Weak topic detected | 10 — Quiz actionability | Evidence-driven priority and remediation |
| 240 | ↓ | 10 — Quiz actionability | Evidence-driven priority and remediation |
| 241 | Increase revision priority | 10 — Quiz actionability | Evidence-driven priority and remediation |
| 242 | ↓ | 10 — Quiz actionability | Evidence-driven priority and remediation |
| 243 | Generate targeted flashcards | 10 — Quiz actionability | Evidence-driven priority and remediation |
| 244 | ↓ | 10 — Quiz actionability | Evidence-driven priority and remediation |
| 245 | Generate practice questions | 10 — Quiz actionability | Evidence-driven priority and remediation |
| 246 | ↓ | 10 — Quiz actionability | Evidence-driven priority and remediation |
| 247 | Schedule review | 10 — Quiz actionability | Evidence-driven priority and remediation |
| 248 | ↓ | 10 — Quiz actionability | Evidence-driven priority and remediation |
| 249 | Retest | 10 — Quiz actionability | Evidence-driven priority and remediation |
| 250 | Don't just show: | 10 — Quiz actionability | Evidence-driven priority and remediation |
| 251 | "You scored 42%." | 10 — Quiz actionability | Evidence-driven priority and remediation |
| 252 | Make the result actionable. | 10 — Quiz actionability | Evidence-driven priority and remediation |
| 253 | 11. BUILD A SUBJECT MASTERY SYSTEM | 11 — Mastery | Evidence-weighted topic projections |
| 254 | Each subject should have a mastery overview. | 11 — Mastery | Evidence-weighted topic projections |
| 255 | Example: | 11 — Mastery | Evidence-weighted topic projections |
| 256 | PHYSICS | 11 — Mastery | Evidence-weighted topic projections |
| 257 | — | 11 — Mastery | Evidence-weighted topic projections |
| 258 | Mechanics       █████████░ 90% | 11 — Mastery | Evidence-weighted topic projections |
| 259 | Waves           ██████░░░░ 62% | 11 — Mastery | Evidence-weighted topic projections |
| 260 | Electricity     ████░░░░░░ 41% | 11 — Mastery | Evidence-weighted topic projections |
| 261 | Magnetism       ███████░░░ 70% | 11 — Mastery | Evidence-weighted topic projections |
| 262 | The exact visualization can vary. | 11 — Mastery | Evidence-weighted topic projections |
| 263 | The important thing is that mastery should be based on meaningful evidence: | 11 — Mastery | Evidence-weighted topic projections |
| 264 | quiz performance | 11 — Mastery | Evidence-weighted topic projections |
| 265 | flashcard performance | 11 — Mastery | Evidence-weighted topic projections |
| 266 | study activity | 11 — Mastery | Evidence-weighted topic projections |
| 267 | completed practice | 11 — Mastery | Evidence-weighted topic projections |
| 268 | exam results | 11 — Mastery | Evidence-weighted topic projections |
| 269 | Do NOT simply equate: | 11 — Mastery | Evidence-weighted topic projections |
| 270 | 3 hours studied = 80% mastery. | 11 — Mastery | Evidence-weighted topic projections |
| 271 | 12. CREATE A KNOWLEDGE HUB | 12 — Knowledge hub | Connected subject/topic resources |
| 272 | Every subject should have a central place containing: | 12 — Knowledge hub | Connected subject/topic resources |
| 273 | SUBJECT | 12 — Knowledge hub | Connected subject/topic resources |
| 274 | │ | 12 — Knowledge hub | Connected subject/topic resources |
| 275 | ├── Notes | 12 — Knowledge hub | Connected subject/topic resources |
| 276 | ├── Topics | 12 — Knowledge hub | Connected subject/topic resources |
| 277 | ├── Flashcards | 12 — Knowledge hub | Connected subject/topic resources |
| 278 | ├── Quizzes | 12 — Knowledge hub | Connected subject/topic resources |
| 279 | ├── Study Sessions | 12 — Knowledge hub | Connected subject/topic resources |
| 280 | ├── Exams | 12 — Knowledge hub | Connected subject/topic resources |
| 281 | ├── Files | 12 — Knowledge hub | Connected subject/topic resources |
| 282 | └── Progress | 12 — Knowledge hub | Connected subject/topic resources |
| 283 | This should become the student's academic knowledge base. | 12 — Knowledge hub | Connected subject/topic resources |
| 284 | 13. NOTES SHOULD CONNECT TO LEARNING | 13 — Connected notes | Canonical note/topic/exam links |
| 285 | Don't build a generic notes app. | 13 — Connected notes | Canonical note/topic/exam links |
| 286 | A note should be able to connect to: | 13 — Connected notes | Canonical note/topic/exam links |
| 287 | subject | 13 — Connected notes | Canonical note/topic/exam links |
| 288 | topic | 13 — Connected notes | Canonical note/topic/exam links |
| 289 | exam | 13 — Connected notes | Canonical note/topic/exam links |
| 290 | flashcards | 13 — Connected notes | Canonical note/topic/exam links |
| 291 | quiz | 13 — Connected notes | Canonical note/topic/exam links |
| 292 | study session | 13 — Connected notes | Canonical note/topic/exam links |
| 293 | Example: | 13 — Connected notes | Canonical note/topic/exam links |
| 294 | Physics | 13 — Connected notes | Canonical note/topic/exam links |
| 295 | └── Electricity | 13 — Connected notes | Canonical note/topic/exam links |
| 296 | └── Ohm's Law | 13 — Connected notes | Canonical note/topic/exam links |
| 297 | ├── Note | 13 — Connected notes | Canonical note/topic/exam links |
| 298 | ├── Flashcards | 13 — Connected notes | Canonical note/topic/exam links |
| 299 | ├── Quiz | 13 — Connected notes | Canonical note/topic/exam links |
| 300 | └── Exam | 13 — Connected notes | Canonical note/topic/exam links |
| 301 | This creates a connected academic knowledge system. | 13 — Connected notes | Canonical note/topic/exam links |
| 302 | 14. PDF/STUDY MATERIAL SYSTEM | 14 — Materials | Account-owned consent-gated material workflows |
| 303 | Allow students to upload: | 14 — Materials | Account-owned consent-gated material workflows |
| 304 | lecture notes | 14 — Materials | Account-owned consent-gated material workflows |
| 305 | PDFs | 14 — Materials | Account-owned consent-gated material workflows |
| 306 | worksheets | 14 — Materials | Account-owned consent-gated material workflows |
| 307 | past questions | 14 — Materials | Account-owned consent-gated material workflows |
| 308 | study documents | 14 — Materials | Account-owned consent-gated material workflows |
| 309 | Then provide actions such as: | 14 — Materials | Account-owned consent-gated material workflows |
| 310 | Summarize | 14 — Materials | Account-owned consent-gated material workflows |
| 311 | Explain | 14 — Materials | Account-owned consent-gated material workflows |
| 312 | Create flashcards | 14 — Materials | Account-owned consent-gated material workflows |
| 313 | Create quiz | 14 — Materials | Account-owned consent-gated material workflows |
| 314 | Find key concepts | 14 — Materials | Account-owned consent-gated material workflows |
| 315 | Generate revision guide | 14 — Materials | Account-owned consent-gated material workflows |
| 316 | Ask questions about this document | 14 — Materials | Account-owned consent-gated material workflows |
| 317 | But maintain strong privacy and security. | 14 — Materials | Account-owned consent-gated material workflows |
| 318 | Do not automatically send every uploaded document to AI. | 14 — Materials | Account-owned consent-gated material workflows |
| 319 | Only process it when the student explicitly requests an AI operation. | 14 — Materials | Account-owned consent-gated material workflows |
| 320 | 15. AI STUDY ASSISTANT SHOULD UNDERSTAND CONTEXT | 15 — AI context/privacy | Protected minimal-context assistant |
| 321 | Instead of being a generic chatbot, Student OS AI should understand the student's academic workspace. | 15 — AI context/privacy | Protected minimal-context assistant |
| 322 | If the student asks: | 15 — AI context/privacy | Protected minimal-context assistant |
| 323 | "What should I study tonight?" | 15 — AI context/privacy | Protected minimal-context assistant |
| 324 | the assistant should consider: | 15 — AI context/privacy | Protected minimal-context assistant |
| 325 | upcoming exams | 15 — AI context/privacy | Protected minimal-context assistant |
| 326 | weak topics | 15 — AI context/privacy | Protected minimal-context assistant |
| 327 | deadlines | 15 — AI context/privacy | Protected minimal-context assistant |
| 328 | timetable | 15 — AI context/privacy | Protected minimal-context assistant |
| 329 | available time | 15 — AI context/privacy | Protected minimal-context assistant |
| 330 | recent study sessions | 15 — AI context/privacy | Protected minimal-context assistant |
| 331 | Then respond with an actionable recommendation. | 15 — AI context/privacy | Protected minimal-context assistant |
| 332 | Example: | 15 — AI context/privacy | Protected minimal-context assistant |
| 333 | You have 45 minutes tonight. Your Physics exam is approaching and Waves is currently your weakest topic. | 15 — AI context/privacy | Protected minimal-context assistant |
| 334 | Recommended: | 15 — AI context/privacy | Protected minimal-context assistant |
| 335 | 25 min — Review Waves notes | 15 — AI context/privacy | Protected minimal-context assistant |
| 336 | 15 min — Practice questions | 15 — AI context/privacy | Protected minimal-context assistant |
| 337 | 5 min — Flashcards | 15 — AI context/privacy | Protected minimal-context assistant |
| 338 | IMPORTANT PRIVACY RULE | 15 — AI context/privacy | Protected minimal-context assistant |
| 339 | Do not send the entire Student OS workspace to the AI. | 15 — AI context/privacy | Protected minimal-context assistant |
| 340 | Construct a minimal relevant context. | 15 — AI context/privacy | Protected minimal-context assistant |
| 341 | 16. QUICK ADD MUST BECOME A CORE FEATURE | 16 — Quick Add | Previewed natural-language drafts |
| 342 | Student should be able to quickly type: | 16 — Quick Add | Previewed natural-language drafts |
| 343 | "Physics exam Sept 20" | 16 — Quick Add | Previewed natural-language drafts |
| 344 | and Student OS understands: | 16 — Quick Add | Previewed natural-language drafts |
| 345 | Type: Exam | 16 — Quick Add | Previewed natural-language drafts |
| 346 | Subject: Physics | 16 — Quick Add | Previewed natural-language drafts |
| 347 | Date: September 20 | 16 — Quick Add | Previewed natural-language drafts |
| 348 | Also: | 16 — Quick Add | Previewed natural-language drafts |
| 349 | "Study Chemistry tomorrow 6pm for 45 mins" | 16 — Quick Add | Previewed natural-language drafts |
| 350 | becomes: | 16 — Quick Add | Previewed natural-language drafts |
| 351 | Study session | 16 — Quick Add | Previewed natural-language drafts |
| 352 | Subject: Chemistry | 16 — Quick Add | Previewed natural-language drafts |
| 353 | Date: tomorrow | 16 — Quick Add | Previewed natural-language drafts |
| 354 | Time: 18:00 | 16 — Quick Add | Previewed natural-language drafts |
| 355 | Duration: 45 minutes | 16 — Quick Add | Previewed natural-language drafts |
| 356 | Quick Add should understand natural language but always show a confirmation preview for ambiguous actions. | 16 — Quick Add | Previewed natural-language drafts |
| 357 | 17. BUILD A REAL FOCUS MODE | 17 — Focus | Objective-linked canonical effort evidence |
| 358 | Focus should connect to the rest of Student OS. | 17 — Focus | Objective-linked canonical effort evidence |
| 359 | Instead of a generic timer: | 17 — Focus | Objective-linked canonical effort evidence |
| 360 | 25:00 | 17 — Focus | Objective-linked canonical effort evidence |
| 361 | show: | 17 — Focus | Objective-linked canonical effort evidence |
| 362 | FOCUS SESSION | 17 — Focus | Objective-linked canonical effort evidence |
| 363 | — | 17 — Focus | Objective-linked canonical effort evidence |
| 364 | Physics | 17 — Focus | Objective-linked canonical effort evidence |
| 365 | Electricity | 17 — Focus | Objective-linked canonical effort evidence |
| 366 | 45 minutes | 17 — Focus | Objective-linked canonical effort evidence |
| 367 | — | 17 — Focus | Objective-linked canonical effort evidence |
| 368 | Goal: | 17 — Focus | Objective-linked canonical effort evidence |
| 369 | Complete 20 practice questions | 17 — Focus | Objective-linked canonical effort evidence |
| 370 | When complete: | 17 — Focus | Objective-linked canonical effort evidence |
| 371 | Session complete ✓ | 17 — Focus | Objective-linked canonical effort evidence |
| 372 | — | 17 — Focus | Objective-linked canonical effort evidence |
| 373 | 45 minutes studied | 17 — Focus | Objective-linked canonical effort evidence |
| 374 | Physics +45 min | 17 — Focus | Objective-linked canonical effort evidence |
| 375 | Electricity practice recorded | 17 — Focus | Objective-linked canonical effort evidence |
| 376 | — | 17 — Focus | Objective-linked canonical effort evidence |
| 377 | Next recommended: | 17 — Focus | Objective-linked canonical effort evidence |
| 378 | Review 8 flashcards | 17 — Focus | Objective-linked canonical effort evidence |
| 379 | This makes focus part of the learning system. | 17 — Focus | Objective-linked canonical effort evidence |
| 380 | 18. GAMIFICATION MUST REWARD REAL LEARNING | 18 — Gamification | One-time reward and evidence safeguards |
| 381 | Keep: | 18 — Gamification | One-time reward and evidence safeguards |
| 382 | XP | 18 — Gamification | One-time reward and evidence safeguards |
| 383 | levels | 18 — Gamification | One-time reward and evidence safeguards |
| 384 | streaks | 18 — Gamification | One-time reward and evidence safeguards |
| 385 | achievements | 18 — Gamification | One-time reward and evidence safeguards |
| 386 | But don't make them exploitable. | 18 — Gamification | One-time reward and evidence safeguards |
| 387 | Reward: | 18 — Gamification | One-time reward and evidence safeguards |
| 388 | completing real study sessions | 18 — Gamification | One-time reward and evidence safeguards |
| 389 | completing meaningful tasks | 18 — Gamification | One-time reward and evidence safeguards |
| 390 | completing quizzes | 18 — Gamification | One-time reward and evidence safeguards |
| 391 | maintaining study consistency | 18 — Gamification | One-time reward and evidence safeguards |
| 392 | reviewing flashcards | 18 — Gamification | One-time reward and evidence safeguards |
| 393 | reaching academic goals | 18 — Gamification | One-time reward and evidence safeguards |
| 394 | Do not allow students to farm XP by repeatedly clicking buttons. | 18 — Gamification | One-time reward and evidence safeguards |
| 395 | 19. STREAKS SHOULD NOT BECOME TOXIC | 19 — Streak tone | Supportive streak and goal UX |
| 396 | A missed day should not make the student feel like they have "failed." | 19 — Streak tone | Supportive streak and goal UX |
| 397 | Instead of: | 19 — Streak tone | Supportive streak and goal UX |
| 398 | STREAK LOST 😭 | 19 — Streak tone | Supportive streak and goal UX |
| 399 | consider: | 19 — Streak tone | Supportive streak and goal UX |
| 400 | Your streak ended. That's okay — let's restart today. | 19 — Streak tone | Supportive streak and goal UX |
| 401 | Focus on consistency rather than punishment. | 19 — Streak tone | Supportive streak and goal UX |
| 402 | 20. SMART NOTIFICATIONS | 20 — Notifications | Categories, quiet hours, caps, ownership |
| 403 | Notifications should be useful, not spammy. | 20 — Notifications | Categories, quiet hours, caps, ownership |
| 404 | Examples: | 20 — Notifications | Categories, quiet hours, caps, ownership |
| 405 | Physics exam in 7 days. | 20 — Notifications | Categories, quiet hours, caps, ownership |
| 406 | You have 30 minutes available before your next class. Want to review your priority topic? | 20 — Notifications | Categories, quiet hours, caps, ownership |
| 407 | 8 flashcards are due today. | 20 — Notifications | Categories, quiet hours, caps, ownership |
| 408 | Your Chemistry assignment is due tomorrow. | 20 — Notifications | Categories, quiet hours, caps, ownership |
| 409 | Avoid excessive notifications. | 20 — Notifications | Categories, quiet hours, caps, ownership |
| 410 | Give students control over notification categories. | 20 — Notifications | Categories, quiet hours, caps, ownership |
| 411 | 21. GLOBAL SEARCH | 21 — Search | Connected canonical global search |
| 412 | Search should eventually cover: | 21 — Search | Connected canonical global search |
| 413 | Tasks | 21 — Search | Connected canonical global search |
| 414 | Notes | 21 — Search | Connected canonical global search |
| 415 | Subjects | 21 — Search | Connected canonical global search |
| 416 | Exams | 21 — Search | Connected canonical global search |
| 417 | Flashcards | 21 — Search | Connected canonical global search |
| 418 | Quizzes | 21 — Search | Connected canonical global search |
| 419 | Study sessions | 21 — Search | Connected canonical global search |
| 420 | Files | 21 — Search | Connected canonical global search |
| 421 | Goals | 21 — Search | Connected canonical global search |
| 422 | AI chats | 21 — Search | Connected canonical global search |
| 423 | Timetable | 21 — Search | Connected canonical global search |
| 424 | Achievements | 21 — Search | Connected canonical global search |
| 425 | Search should be fast. | 21 — Search | Connected canonical global search |
| 426 | Add filters: | 21 — Search | Connected canonical global search |
| 427 | Everything | 21 — Search | Connected canonical global search |
| 428 | Notes | 21 — Search | Connected canonical global search |
| 429 | Tasks | 21 — Search | Connected canonical global search |
| 430 | Files | 21 — Search | Connected canonical global search |
| 431 | Study | 21 — Search | Connected canonical global search |
| 432 | Exams | 21 — Search | Connected canonical global search |
| 433 | 22. DASHBOARD CUSTOMIZATION | 22 — Dashboard customization | Sensible defaults; unlimited layout intentionally deferred |
| 434 | Students have different workflows. | 22 — Dashboard customization | Sensible defaults; unlimited layout intentionally deferred |
| 435 | Allow them to customize: | 22 — Dashboard customization | Sensible defaults; unlimited layout intentionally deferred |
| 436 | widget visibility | 22 — Dashboard customization | Sensible defaults; unlimited layout intentionally deferred |
| 437 | widget ordering | 22 — Dashboard customization | Sensible defaults; unlimited layout intentionally deferred |
| 438 | quick actions | 22 — Dashboard customization | Sensible defaults; unlimited layout intentionally deferred |
| 439 | preferred study view | 22 — Dashboard customization | Sensible defaults; unlimited layout intentionally deferred |
| 440 | dashboard layout | 22 — Dashboard customization | Sensible defaults; unlimited layout intentionally deferred |
| 441 | But don't make customization overwhelming. | 22 — Dashboard customization | Sensible defaults; unlimited layout intentionally deferred |
| 442 | Provide sensible defaults. | 22 — Dashboard customization | Sensible defaults; unlimited layout intentionally deferred |
| 443 | 23. PERSONALIZED DAILY BRIEFING | 23 — Daily briefing | Canonical priorities and available capacity |
| 444 | Consider adding: | 23 — Daily briefing | Canonical priorities and available capacity |
| 445 | "Your Day" | 23 — Daily briefing | Canonical priorities and available capacity |
| 446 | At the beginning of the day: | 23 — Daily briefing | Canonical priorities and available capacity |
| 447 | GOOD MORNING 👋 | 23 — Daily briefing | Canonical priorities and available capacity |
| 448 | — | 23 — Daily briefing | Canonical priorities and available capacity |
| 449 | Today's priorities: | 23 — Daily briefing | Canonical priorities and available capacity |
| 450 | — | 23 — Daily briefing | Canonical priorities and available capacity |
| 451 | 🔴 Chemistry assignment — due today | 23 — Daily briefing | Canonical priorities and available capacity |
| 452 | 🟠 Physics revision — exam in 5 days | 23 — Daily briefing | Canonical priorities and available capacity |
| 453 | 🟢 12 flashcards due | 23 — Daily briefing | Canonical priorities and available capacity |
| 454 | — | 23 — Daily briefing | Canonical priorities and available capacity |
| 455 | You have approximately 2h 15m of available study time. | 23 — Daily briefing | Canonical priorities and available capacity |
| 456 | — | 23 — Daily briefing | Canonical priorities and available capacity |
| 457 | Recommended plan: | 23 — Daily briefing | Canonical priorities and available capacity |
| 458 | ... | 23 — Daily briefing | Canonical priorities and available capacity |
| 459 | This should become one of Student OS's signature experiences. | 23 — Daily briefing | Canonical priorities and available capacity |
| 460 | 24. END-OF-DAY REVIEW | 24 — End-of-day review | Canonical daily review and plan preparation |
| 461 | At the end of the day: | 24 — End-of-day review | Canonical daily review and plan preparation |
| 462 | TODAY'S REVIEW | 24 — End-of-day review | Canonical daily review and plan preparation |
| 463 | — | 24 — End-of-day review | Canonical daily review and plan preparation |
| 464 | Study time: | 24 — End-of-day review | Canonical daily review and plan preparation |
| 465 | 1h 42m | 24 — End-of-day review | Canonical daily review and plan preparation |
| 466 | — | 24 — End-of-day review | Canonical daily review and plan preparation |
| 467 | Tasks: | 24 — End-of-day review | Canonical daily review and plan preparation |
| 468 | 4 / 5 complete | 24 — End-of-day review | Canonical daily review and plan preparation |
| 469 | — | 24 — End-of-day review | Canonical daily review and plan preparation |
| 470 | Flashcards: | 24 — End-of-day review | Canonical daily review and plan preparation |
| 471 | 32 reviewed | 24 — End-of-day review | Canonical daily review and plan preparation |
| 472 | — | 24 — End-of-day review | Canonical daily review and plan preparation |
| 473 | Quiz: | 24 — End-of-day review | Canonical daily review and plan preparation |
| 474 | Physics — 78% | 24 — End-of-day review | Canonical daily review and plan preparation |
| 475 | — | 24 — End-of-day review | Canonical daily review and plan preparation |
| 476 | Tomorrow: | 24 — End-of-day review | Canonical daily review and plan preparation |
| 477 | Chemistry assignment | 24 — End-of-day review | Canonical daily review and plan preparation |
| 478 | Physics revision | 24 — End-of-day review | Canonical daily review and plan preparation |
| 479 | 24 flashcards due | 24 — End-of-day review | Canonical daily review and plan preparation |
| 480 | Then: | 24 — End-of-day review | Canonical daily review and plan preparation |
| 481 | Prepare tomorrow | 24 — End-of-day review | Canonical daily review and plan preparation |
| 482 | The system can propose a schedule. | 24 — End-of-day review | Canonical daily review and plan preparation |
| 483 | 25. WEEKLY REVIEW | 25 — Weekly review | Canonical weekly evidence and recommendations |
| 484 | Create: | 25 — Weekly review | Canonical weekly evidence and recommendations |
| 485 | WEEKLY ACADEMIC REVIEW | 25 — Weekly review | Canonical weekly evidence and recommendations |
| 486 | Show: | 25 — Weekly review | Canonical weekly evidence and recommendations |
| 487 | study hours | 25 — Weekly review | Canonical weekly evidence and recommendations |
| 488 | consistency | 25 — Weekly review | Canonical weekly evidence and recommendations |
| 489 | subjects studied | 25 — Weekly review | Canonical weekly evidence and recommendations |
| 490 | quiz performance | 25 — Weekly review | Canonical weekly evidence and recommendations |
| 491 | weak topics | 25 — Weekly review | Canonical weekly evidence and recommendations |
| 492 | completed tasks | 25 — Weekly review | Canonical weekly evidence and recommendations |
| 493 | upcoming exams | 25 — Weekly review | Canonical weekly evidence and recommendations |
| 494 | goal progress | 25 — Weekly review | Canonical weekly evidence and recommendations |
| 495 | Then provide: | 25 — Weekly review | Canonical weekly evidence and recommendations |
| 496 | What should I improve next week? | 25 — Weekly review | Canonical weekly evidence and recommendations |
| 497 | AI can generate a concise recommendation using relevant data. | 25 — Weekly review | Canonical weekly evidence and recommendations |
| 498 | 26. SMART STUDY RECOMMENDATIONS | 26 — Recommendation ranking | Single deterministic next-action engine |
| 499 | Student OS should eventually rank possible actions. | 26 — Recommendation ranking | Single deterministic next-action engine |
| 500 | Example: | 26 — Recommendation ranking | Single deterministic next-action engine |
| 501 | WHAT SHOULD I DO NOW? | 26 — Recommendation ranking | Single deterministic next-action engine |
| 502 | — | 26 — Recommendation ranking | Single deterministic next-action engine |
| 503 | 1. 🔴 Chemistry assignment | 26 — Recommendation ranking | Single deterministic next-action engine |
| 504 | Due tomorrow | 26 — Recommendation ranking | Single deterministic next-action engine |
| 505 | 35 min | 26 — Recommendation ranking | Single deterministic next-action engine |
| 506 | — | 26 — Recommendation ranking | Single deterministic next-action engine |
| 507 | 2. 🟠 Physics — Waves | 26 — Recommendation ranking | Single deterministic next-action engine |
| 508 | Weak topic | 26 — Recommendation ranking | Single deterministic next-action engine |
| 509 | 30 min | 26 — Recommendation ranking | Single deterministic next-action engine |
| 510 | — | 26 — Recommendation ranking | Single deterministic next-action engine |
| 511 | 3. 🟢 Flashcards | 26 — Recommendation ranking | Single deterministic next-action engine |
| 512 | 18 due | 26 — Recommendation ranking | Single deterministic next-action engine |
| 513 | 12 min | 26 — Recommendation ranking | Single deterministic next-action engine |
| 514 | The ranking should consider: | 26 — Recommendation ranking | Single deterministic next-action engine |
| 515 | urgency | 26 — Recommendation ranking | Single deterministic next-action engine |
| 516 | importance | 26 — Recommendation ranking | Single deterministic next-action engine |
| 517 | weakness | 26 — Recommendation ranking | Single deterministic next-action engine |
| 518 | available time | 26 — Recommendation ranking | Single deterministic next-action engine |
| 519 | exam proximity | 26 — Recommendation ranking | Single deterministic next-action engine |
| 520 | prerequisites | 26 — Recommendation ranking | Single deterministic next-action engine |
| 521 | 27. CALENDAR + TIMETABLE + STUDY PLAN | 27 — Calendar | Connected calendar/timetable/plan model |
| 522 | These should not be isolated features. | 27 — Calendar | Connected calendar/timetable/plan model |
| 523 | Create one unified scheduling system. | 27 — Calendar | Connected calendar/timetable/plan model |
| 524 | Potential event types: | 27 — Calendar | Connected calendar/timetable/plan model |
| 525 | Class | 27 — Calendar | Connected calendar/timetable/plan model |
| 526 | Study | 27 — Calendar | Connected calendar/timetable/plan model |
| 527 | Exam | 27 — Calendar | Connected calendar/timetable/plan model |
| 528 | Assignment | 27 — Calendar | Connected calendar/timetable/plan model |
| 529 | Personal | 27 — Calendar | Connected calendar/timetable/plan model |
| 530 | Reminder | 27 — Calendar | Connected calendar/timetable/plan model |
| 531 | Then allow different views: | 27 — Calendar | Connected calendar/timetable/plan model |
| 532 | Today | 27 — Calendar | Connected calendar/timetable/plan model |
| 533 | Week | 27 — Calendar | Connected calendar/timetable/plan model |
| 534 | Month | 27 — Calendar | Connected calendar/timetable/plan model |
| 535 | Agenda | 27 — Calendar | Connected calendar/timetable/plan model |
| 536 | 28. BUDGET SHOULD FEEL LIKE PART OF STUDENT LIFE | 28 — Budget | Simple canonical budget with local currency |
| 537 | Keep the budget system, but make it simple. | 28 — Budget | Simple canonical budget with local currency |
| 538 | Track: | 28 — Budget | Simple canonical budget with local currency |
| 539 | allowance/income | 28 — Budget | Simple canonical budget with local currency |
| 540 | spending | 28 — Budget | Simple canonical budget with local currency |
| 541 | categories | 28 — Budget | Simple canonical budget with local currency |
| 542 | monthly budget | 28 — Budget | Simple canonical budget with local currency |
| 543 | savings goals | 28 — Budget | Simple canonical budget with local currency |
| 544 | Support configurable currency. | 28 — Budget | Simple canonical budget with local currency |
| 545 | Do not turn Student OS into a complicated banking application. | 28 — Budget | Simple canonical budget with local currency |
| 546 | 29. CLOUD ACCOUNT | 29 — Cloud/local-first | Authenticated workspace hydration, sync, conflict merge |
| 547 | Maintain the architecture we already decided: | 29 — Cloud/local-first | Authenticated workspace hydration, sync, conflict merge |
| 548 | AUTHENTICATED + CLOUD-BACKED + LOCAL-FIRST | 29 — Cloud/local-first | Authenticated workspace hydration, sync, conflict merge |
| 549 | Student data should survive: | 29 — Cloud/local-first | Authenticated workspace hydration, sync, conflict merge |
| 550 | phone replacement | 29 — Cloud/local-first | Authenticated workspace hydration, sync, conflict merge |
| 551 | reinstall | 29 — Cloud/local-first | Authenticated workspace hydration, sync, conflict merge |
| 552 | device loss | 29 — Cloud/local-first | Authenticated workspace hydration, sync, conflict merge |
| 553 | multi-device use | 29 — Cloud/local-first | Authenticated workspace hydration, sync, conflict merge |
| 554 | Cloud: | 29 — Cloud/local-first | Authenticated workspace hydration, sync, conflict merge |
| 555 | persistent workspace | 29 — Cloud/local-first | Authenticated workspace hydration, sync, conflict merge |
| 556 | Local: | 29 — Cloud/local-first | Authenticated workspace hydration, sync, conflict merge |
| 557 | fast/offline copy | 29 — Cloud/local-first | Authenticated workspace hydration, sync, conflict merge |
| 558 | Synchronization: | 29 — Cloud/local-first | Authenticated workspace hydration, sync, conflict merge |
| 559 | keeps them consistent | 29 — Cloud/local-first | Authenticated workspace hydration, sync, conflict merge |
| 560 | 30. COMMUNITY / SHARED MATERIALS — FUTURE FEATURE | 30 — Sharing | Deferred pending moderation and privacy architecture |
| 561 | StudySmarter demonstrates the power of student-created resources, including notes, flashcards and past exams. � | 30 — Sharing | Deferred pending moderation and privacy architecture |
| 562 | Google Play | 30 — Sharing | Deferred pending moderation and privacy architecture |
| 563 | Do NOT immediately build a giant social network. | 30 — Sharing | Deferred pending moderation and privacy architecture |
| 564 | Instead, architect Student OS so a future feature could allow: | 30 — Sharing | Deferred pending moderation and privacy architecture |
| 565 | Share this flashcard deck | 30 — Sharing | Deferred pending moderation and privacy architecture |
| 566 | Share these notes | 30 — Sharing | Deferred pending moderation and privacy architecture |
| 567 | Share this study guide | 30 — Sharing | Deferred pending moderation and privacy architecture |
| 568 | Potential future: | 30 — Sharing | Deferred pending moderation and privacy architecture |
| 569 | Student OS Library | 30 — Sharing | Deferred pending moderation and privacy architecture |
| 570 | ├── Public | 30 — Sharing | Deferred pending moderation and privacy architecture |
| 571 | ├── School | 30 — Sharing | Deferred pending moderation and privacy architecture |
| 572 | ├── Class | 30 — Sharing | Deferred pending moderation and privacy architecture |
| 573 | └── Private | 30 — Sharing | Deferred pending moderation and privacy architecture |
| 574 | But privacy and moderation must be designed before releasing this. | 30 — Sharing | Deferred pending moderation and privacy architecture |
| 575 | 31. GHANA-FIRST OPPORTUNITY | 31 — Ghana context | Optional cited NaCCA secondary provenance seed |
| 576 | Student OS should eventually understand the educational environment it is actually serving. | 31 — Ghana context | Optional cited NaCCA secondary provenance seed |
| 577 | Do not design exclusively around American college workflows. | 31 — Ghana context | Optional cited NaCCA secondary provenance seed |
| 578 | Build the architecture so it can support: | 31 — Ghana context | Optional cited NaCCA secondary provenance seed |
| 579 | SHS | 31 — Ghana context | Optional cited NaCCA secondary provenance seed |
| 580 | university | 31 — Ghana context | Optional cited NaCCA secondary provenance seed |
| 581 | vocational/technical education | 31 — Ghana context | Optional cited NaCCA secondary provenance seed |
| 582 | WASSCE | 31 — Ghana context | Optional cited NaCCA secondary provenance seed |
| 583 | university exams | 31 — Ghana context | Optional cited NaCCA secondary provenance seed |
| 584 | course-based university systems | 31 — Ghana context | Optional cited NaCCA secondary provenance seed |
| 585 | Ghanaian academic calendars | 31 — Ghana context | Optional cited NaCCA secondary provenance seed |
| 586 | Potential future integrations/content could include: | 31 — Ghana context | Optional cited NaCCA secondary provenance seed |
| 587 | WASSCE subjects | 31 — Ghana context | Optional cited NaCCA secondary provenance seed |
| 588 | Ghana-specific syllabuses | 31 — Ghana context | Optional cited NaCCA secondary provenance seed |
| 589 | past questions | 31 — Ghana context | Optional cited NaCCA secondary provenance seed |
| 590 | school/course structures | 31 — Ghana context | Optional cited NaCCA secondary provenance seed |
| 591 | This could become a major differentiation point. | 31 — Ghana context | Optional cited NaCCA secondary provenance seed |
| 592 | 32. DON'T COPY OTHER APPS' WEAKNESSES | 32 — Connected simplicity | One workspace and learning-intelligence system |
| 593 | Student OS should NOT become: | 32 — Connected simplicity | One workspace and learning-intelligence system |
| 594 | Notion + Quizlet + Anki + Todoist + Forest + Google Calendar smashed together. | 32 — Connected simplicity | One workspace and learning-intelligence system |
| 595 | That would create a bloated application. | 32 — Connected simplicity | One workspace and learning-intelligence system |
| 596 | Instead: | 32 — Connected simplicity | One workspace and learning-intelligence system |
| 597 | CONNECT THE FEATURES. | 32 — Connected simplicity | One workspace and learning-intelligence system |
| 598 | Example: | 32 — Connected simplicity | One workspace and learning-intelligence system |
| 599 | EXAM | 32 — Connected simplicity | One workspace and learning-intelligence system |
| 600 | ↓ | 32 — Connected simplicity | One workspace and learning-intelligence system |
| 601 | Study Plan | 32 — Connected simplicity | One workspace and learning-intelligence system |
| 602 | ↓ | 32 — Connected simplicity | One workspace and learning-intelligence system |
| 603 | Study Session | 32 — Connected simplicity | One workspace and learning-intelligence system |
| 604 | ↓ | 32 — Connected simplicity | One workspace and learning-intelligence system |
| 605 | Notes | 32 — Connected simplicity | One workspace and learning-intelligence system |
| 606 | ↓ | 32 — Connected simplicity | One workspace and learning-intelligence system |
| 607 | Flashcards | 32 — Connected simplicity | One workspace and learning-intelligence system |
| 608 | ↓ | 32 — Connected simplicity | One workspace and learning-intelligence system |
| 609 | Quiz | 32 — Connected simplicity | One workspace and learning-intelligence system |
| 610 | ↓ | 32 — Connected simplicity | One workspace and learning-intelligence system |
| 611 | Weak Topic | 32 — Connected simplicity | One workspace and learning-intelligence system |
| 612 | ↓ | 32 — Connected simplicity | One workspace and learning-intelligence system |
| 613 | Additional Study | 32 — Connected simplicity | One workspace and learning-intelligence system |
| 614 | ↓ | 32 — Connected simplicity | One workspace and learning-intelligence system |
| 615 | Retest | 32 — Connected simplicity | One workspace and learning-intelligence system |
| 616 | ↓ | 32 — Connected simplicity | One workspace and learning-intelligence system |
| 617 | Mastery | 32 — Connected simplicity | One workspace and learning-intelligence system |
| 618 | That's the Student OS advantage. | 32 — Connected simplicity | One workspace and learning-intelligence system |
| 619 | 33. THE "ONE STUDENT, ONE SYSTEM" PRINCIPLE | 33 — One student system | Canonical state with AI as bounded layer |
| 620 | Everything should contribute to one unified student model. | 33 — One student system | Canonical state with AI as bounded layer |
| 621 | Conceptually: | 33 — One student system | Canonical state with AI as bounded layer |
| 622 | STUDENT | 33 — One student system | Canonical state with AI as bounded layer |
| 623 | │ | 33 — One student system | Canonical state with AI as bounded layer |
| 624 | ┌────────────┼────────────┐ | 33 — One student system | Canonical state with AI as bounded layer |
| 625 | ↓            ↓            ↓ | 33 — One student system | Canonical state with AI as bounded layer |
| 626 | ACADEMICS   PRODUCTIVITY   PERSONAL | 33 — One student system | Canonical state with AI as bounded layer |
| 627 | │            │            │ | 33 — One student system | Canonical state with AI as bounded layer |
| 628 | Subjects       Tasks        Goals | 33 — One student system | Canonical state with AI as bounded layer |
| 629 | Exams          Calendar      Habits | 33 — One student system | Canonical state with AI as bounded layer |
| 630 | Notes          Focus         Budget | 33 — One student system | Canonical state with AI as bounded layer |
| 631 | Flashcards     Reminders | 33 — One student system | Canonical state with AI as bounded layer |
| 632 | Quizzes | 33 — One student system | Canonical state with AI as bounded layer |
| 633 | │ | 33 — One student system | Canonical state with AI as bounded layer |
| 634 | └───────────┐ | 33 — One student system | Canonical state with AI as bounded layer |
| 635 | ↓ | 33 — One student system | Canonical state with AI as bounded layer |
| 636 | AI ENGINE | 33 — One student system | Canonical state with AI as bounded layer |
| 637 | │ | 33 — One student system | Canonical state with AI as bounded layer |
| 638 | ↓ | 33 — One student system | Canonical state with AI as bounded layer |
| 639 | RECOMMENDATIONS | 33 — One student system | Canonical state with AI as bounded layer |
| 640 | The AI should not be the center of Student OS. | 33 — One student system | Canonical state with AI as bounded layer |
| 641 | The student's data and learning workflow are the center. | 33 — One student system | Canonical state with AI as bounded layer |
| 642 | AI is the intelligence layer on top. | 33 — One student system | Canonical state with AI as bounded layer |
| 643 | 34. PERFORMANCE REQUIREMENT | 34 — Performance | Lazy chunk and bundle-boundary controls |
| 644 | Do not sacrifice performance for features. | 34 — Performance | Lazy chunk and bundle-boundary controls |
| 645 | Student OS must remain fast on lower-end Android devices. | 34 — Performance | Lazy chunk and bundle-boundary controls |
| 646 | Optimize for: | 34 — Performance | Lazy chunk and bundle-boundary controls |
| 647 | 4GB RAM devices | 34 — Performance | Lazy chunk and bundle-boundary controls |
| 648 | slower processors | 34 — Performance | Lazy chunk and bundle-boundary controls |
| 649 | slower networks | 34 — Performance | Lazy chunk and bundle-boundary controls |
| 650 | limited storage | 34 — Performance | Lazy chunk and bundle-boundary controls |
| 651 | intermittent connectivity | 34 — Performance | Lazy chunk and bundle-boundary controls |
| 652 | Avoid unnecessarily huge bundles. | 34 — Performance | Lazy chunk and bundle-boundary controls |
| 653 | Lazy-load heavy features such as: | 34 — Performance | Lazy chunk and bundle-boundary controls |
| 654 | charts | 34 — Performance | Lazy chunk and bundle-boundary controls |
| 655 | AI interfaces | 34 — Performance | Lazy chunk and bundle-boundary controls |
| 656 | PDF processing | 34 — Performance | Lazy chunk and bundle-boundary controls |
| 657 | advanced analytics | 34 — Performance | Lazy chunk and bundle-boundary controls |
| 658 | 35. MOBILE-FIRST | 35 — Mobile-first | Responsive source contracts; physical-device acceptance manual |
| 659 | Student OS should feel excellent on a phone first. | 35 — Mobile-first | Responsive source contracts; physical-device acceptance manual |
| 660 | Check: | 35 — Mobile-first | Responsive source contracts; physical-device acceptance manual |
| 661 | bottom navigation | 35 — Mobile-first | Responsive source contracts; physical-device acceptance manual |
| 662 | thumb reach | 35 — Mobile-first | Responsive source contracts; physical-device acceptance manual |
| 663 | touch targets | 35 — Mobile-first | Responsive source contracts; physical-device acceptance manual |
| 664 | keyboard behavior | 35 — Mobile-first | Responsive source contracts; physical-device acceptance manual |
| 665 | modal size | 35 — Mobile-first | Responsive source contracts; physical-device acceptance manual |
| 666 | scrolling | 35 — Mobile-first | Responsive source contracts; physical-device acceptance manual |
| 667 | forms | 35 — Mobile-first | Responsive source contracts; physical-device acceptance manual |
| 668 | charts | 35 — Mobile-first | Responsive source contracts; physical-device acceptance manual |
| 669 | timetable | 35 — Mobile-first | Responsive source contracts; physical-device acceptance manual |
| 670 | flashcard controls | 35 — Mobile-first | Responsive source contracts; physical-device acceptance manual |
| 671 | Desktop should be a powerful extension, not the primary design target. | 35 — Mobile-first | Responsive source contracts; physical-device acceptance manual |
| 672 | 36. ACCESSIBILITY | 36 — Accessibility | Targeted semantics and reduced motion; AT acceptance manual |
| 673 | Support: | 36 — Accessibility | Targeted semantics and reduced motion; AT acceptance manual |
| 674 | readable text | 36 — Accessibility | Targeted semantics and reduced motion; AT acceptance manual |
| 675 | adequate contrast | 36 — Accessibility | Targeted semantics and reduced motion; AT acceptance manual |
| 676 | keyboard navigation where applicable | 36 — Accessibility | Targeted semantics and reduced motion; AT acceptance manual |
| 677 | screen-reader labels | 36 — Accessibility | Targeted semantics and reduced motion; AT acceptance manual |
| 678 | accessible buttons | 36 — Accessibility | Targeted semantics and reduced motion; AT acceptance manual |
| 679 | zoom | 36 — Accessibility | Targeted semantics and reduced motion; AT acceptance manual |
| 680 | reduced motion where appropriate | 36 — Accessibility | Targeted semantics and reduced motion; AT acceptance manual |
| 681 | Do not use tiny icon-only controls without accessible labels. | 36 — Accessibility | Targeted semantics and reduced motion; AT acceptance manual |
| 682 | 37. EMPTY STATES | 37 — Empty states | Audited helpful feature empty states |
| 683 | Every major feature needs a useful empty state. | 37 — Empty states | Audited helpful feature empty states |
| 684 | Instead of: | 37 — Empty states | Audited helpful feature empty states |
| 685 | Nothing here. | 37 — Empty states | Audited helpful feature empty states |
| 686 | Use: | 37 — Empty states | Audited helpful feature empty states |
| 687 | You don't have any exams yet. | 37 — Empty states | Audited helpful feature empty states |
| 688 | Add your first exam to start building your revision plan. | 37 — Empty states | Audited helpful feature empty states |
| 689 | Then: | 37 — Empty states | Audited helpful feature empty states |
| 690 | + Add Exam | 37 — Empty states | Audited helpful feature empty states |
| 691 | 38. ERROR STATES | 38 — Error states | Bounded errors/recovery without raw upstream disclosure |
| 692 | Every network feature needs: | 38 — Error states | Bounded errors/recovery without raw upstream disclosure |
| 693 | Loading | 38 — Error states | Bounded errors/recovery without raw upstream disclosure |
| 694 | Success | 38 — Error states | Bounded errors/recovery without raw upstream disclosure |
| 695 | Empty | 38 — Error states | Bounded errors/recovery without raw upstream disclosure |
| 696 | Error | 38 — Error states | Bounded errors/recovery without raw upstream disclosure |
| 697 | Retry | 38 — Error states | Bounded errors/recovery without raw upstream disclosure |
| 698 | Offline | 38 — Error states | Bounded errors/recovery without raw upstream disclosure |
| 699 | Never leave blank screens. | 38 — Error states | Bounded errors/recovery without raw upstream disclosure |
| 700 | Never expose raw backend errors to students. | 38 — Error states | Bounded errors/recovery without raw upstream disclosure |
| 701 | 39. THE STUDENT OS DIFFERENTIATOR | 39 — Differentiator | Connected next-action philosophy |
| 702 | The goal is NOT: | 39 — Differentiator | Connected next-action philosophy |
| 703 | "We have more features." | 39 — Differentiator | Connected next-action philosophy |
| 704 | The goal is: | 39 — Differentiator | Connected next-action philosophy |
| 705 | "Student OS understands what the student needs to do next." | 39 — Differentiator | Connected next-action philosophy |
| 706 | That should be the product philosophy. | 39 — Differentiator | Connected next-action philosophy |
| 707 | 40. THE FINAL STUDENT OS EXPERIENCE | 40 — Target experience | Implemented as connected capability trajectory, not outcome guarantee |
| 708 | A student opens the app. | 40 — Target experience | Implemented as connected capability trajectory, not outcome guarantee |
| 709 | They see: | 40 — Target experience | Implemented as connected capability trajectory, not outcome guarantee |
| 710 | GOOD MORNING 👋 | 40 — Target experience | Implemented as connected capability trajectory, not outcome guarantee |
| 711 | — | 40 — Target experience | Implemented as connected capability trajectory, not outcome guarantee |
| 712 | Here's what matters today. | 40 — Target experience | Implemented as connected capability trajectory, not outcome guarantee |
| 713 | — | 40 — Target experience | Implemented as connected capability trajectory, not outcome guarantee |
| 714 | 🔴 Chemistry assignment | 40 — Target experience | Implemented as connected capability trajectory, not outcome guarantee |
| 715 | Due today | 40 — Target experience | Implemented as connected capability trajectory, not outcome guarantee |
| 716 | — | 40 — Target experience | Implemented as connected capability trajectory, not outcome guarantee |
| 717 | 🟠 Physics exam | 40 — Target experience | Implemented as connected capability trajectory, not outcome guarantee |
| 718 | 6 days away | 40 — Target experience | Implemented as connected capability trajectory, not outcome guarantee |
| 719 | — | 40 — Target experience | Implemented as connected capability trajectory, not outcome guarantee |
| 720 | 🧠 Weak topic | 40 — Target experience | Implemented as connected capability trajectory, not outcome guarantee |
| 721 | Electromagnetic induction | 40 — Target experience | Implemented as connected capability trajectory, not outcome guarantee |
| 722 | — | 40 — Target experience | Implemented as connected capability trajectory, not outcome guarantee |
| 723 | 🃏 18 flashcards due | 40 — Target experience | Implemented as connected capability trajectory, not outcome guarantee |
| 724 | — | 40 — Target experience | Implemented as connected capability trajectory, not outcome guarantee |
| 725 | ⏱️ 1h 45m available study time | 40 — Target experience | Implemented as connected capability trajectory, not outcome guarantee |
| 726 | Student taps: | 40 — Target experience | Implemented as connected capability trajectory, not outcome guarantee |
| 727 | "Start my study plan" | 40 — Target experience | Implemented as connected capability trajectory, not outcome guarantee |
| 728 | Student OS creates: | 40 — Target experience | Implemented as connected capability trajectory, not outcome guarantee |
| 729 | 18:00 | 40 — Target experience | Implemented as connected capability trajectory, not outcome guarantee |
| 730 | Chemistry assignment | 40 — Target experience | Implemented as connected capability trajectory, not outcome guarantee |
| 731 | 35 min | 40 — Target experience | Implemented as connected capability trajectory, not outcome guarantee |
| 732 | — | 40 — Target experience | Implemented as connected capability trajectory, not outcome guarantee |
| 733 | 18:40 | 40 — Target experience | Implemented as connected capability trajectory, not outcome guarantee |
| 734 | Physics — Electromagnetic Induction | 40 — Target experience | Implemented as connected capability trajectory, not outcome guarantee |
| 735 | 40 min | 40 — Target experience | Implemented as connected capability trajectory, not outcome guarantee |
| 736 | — | 40 — Target experience | Implemented as connected capability trajectory, not outcome guarantee |
| 737 | 19:25 | 40 — Target experience | Implemented as connected capability trajectory, not outcome guarantee |
| 738 | Flashcards | 40 — Target experience | Implemented as connected capability trajectory, not outcome guarantee |
| 739 | 15 min | 40 — Target experience | Implemented as connected capability trajectory, not outcome guarantee |
| 740 | Student completes Physics. | 40 — Target experience | Implemented as connected capability trajectory, not outcome guarantee |
| 741 | Student OS records: | 40 — Target experience | Implemented as connected capability trajectory, not outcome guarantee |
| 742 | +40 min study | 40 — Target experience | Implemented as connected capability trajectory, not outcome guarantee |
| 743 | Physics ↑ | 40 — Target experience | Implemented as connected capability trajectory, not outcome guarantee |
| 744 | Electromagnetic Induction ↑ | 40 — Target experience | Implemented as connected capability trajectory, not outcome guarantee |
| 745 | Student takes a quiz. | 40 — Target experience | Implemented as connected capability trajectory, not outcome guarantee |
| 746 | Score: | 40 — Target experience | Implemented as connected capability trajectory, not outcome guarantee |
| 747 | 61% | 40 — Target experience | Implemented as connected capability trajectory, not outcome guarantee |
| 748 | Student OS identifies: | 40 — Target experience | Implemented as connected capability trajectory, not outcome guarantee |
| 749 | Your weakest area is transformer efficiency. | 40 — Target experience | Implemented as connected capability trajectory, not outcome guarantee |
| 750 | It generates: | 40 — Target experience | Implemented as connected capability trajectory, not outcome guarantee |
| 751 | targeted explanation | 40 — Target experience | Implemented as connected capability trajectory, not outcome guarantee |
| 752 | flashcards | 40 — Target experience | Implemented as connected capability trajectory, not outcome guarantee |
| 753 | practice questions | 40 — Target experience | Implemented as connected capability trajectory, not outcome guarantee |
| 754 | Then schedules another review. | 40 — Target experience | Implemented as connected capability trajectory, not outcome guarantee |
| 755 | That is the experience we are building. | 40 — Target experience | Implemented as connected capability trajectory, not outcome guarantee |
| 756 | 41. IMPLEMENTATION RULE | 41 — Implementation priorities | Incremental P0–P3 delivery with safe deferrals |
| 757 | Do not implement every feature in one giant uncontrolled rewrite. | 41 — Implementation priorities | Incremental P0–P3 delivery with safe deferrals |
| 758 | Prioritize: | 41 — Implementation priorities | Incremental P0–P3 delivery with safe deferrals |
| 759 | P0 — Core Student OS intelligence | 41 — Implementation priorities | Incremental P0–P3 delivery with safe deferrals |
| 760 | Account/cloud architecture | 41 — Implementation priorities | Incremental P0–P3 delivery with safe deferrals |
| 761 | Local-first synchronization | 41 — Implementation priorities | Incremental P0–P3 delivery with safe deferrals |
| 762 | Tasks | 41 — Implementation priorities | Incremental P0–P3 delivery with safe deferrals |
| 763 | Exams | 41 — Implementation priorities | Incremental P0–P3 delivery with safe deferrals |
| 764 | Subjects | 41 — Implementation priorities | Incremental P0–P3 delivery with safe deferrals |
| 765 | Study planner | 41 — Implementation priorities | Incremental P0–P3 delivery with safe deferrals |
| 766 | Study sessions | 41 — Implementation priorities | Incremental P0–P3 delivery with safe deferrals |
| 767 | Flashcards | 41 — Implementation priorities | Incremental P0–P3 delivery with safe deferrals |
| 768 | Quizzes | 41 — Implementation priorities | Incremental P0–P3 delivery with safe deferrals |
| 769 | Progress | 41 — Implementation priorities | Incremental P0–P3 delivery with safe deferrals |
| 770 | P1 — Learning intelligence | 41 — Implementation priorities | Incremental P0–P3 delivery with safe deferrals |
| 771 | Mastery | 41 — Implementation priorities | Incremental P0–P3 delivery with safe deferrals |
| 772 | Weak-topic detection | 41 — Implementation priorities | Incremental P0–P3 delivery with safe deferrals |
| 773 | AI study recommendations | 41 — Implementation priorities | Incremental P0–P3 delivery with safe deferrals |
| 774 | AI flashcard generation | 41 — Implementation priorities | Incremental P0–P3 delivery with safe deferrals |
| 775 | AI quiz generation | 41 — Implementation priorities | Incremental P0–P3 delivery with safe deferrals |
| 776 | PDF/study-material processing | 41 — Implementation priorities | Incremental P0–P3 delivery with safe deferrals |
| 777 | Daily briefing | 41 — Implementation priorities | Incremental P0–P3 delivery with safe deferrals |
| 778 | Weekly review | 41 — Implementation priorities | Incremental P0–P3 delivery with safe deferrals |
| 779 | P2 — Productivity | 41 — Implementation priorities | Incremental P0–P3 delivery with safe deferrals |
| 780 | Calendar/timetable | 41 — Implementation priorities | Incremental P0–P3 delivery with safe deferrals |
| 781 | Notifications | 41 — Implementation priorities | Incremental P0–P3 delivery with safe deferrals |
| 782 | Goals | 41 — Implementation priorities | Incremental P0–P3 delivery with safe deferrals |
| 783 | Habits | 41 — Implementation priorities | Incremental P0–P3 delivery with safe deferrals |
| 784 | Focus mode | 41 — Implementation priorities | Incremental P0–P3 delivery with safe deferrals |
| 785 | Budget | 41 — Implementation priorities | Incremental P0–P3 delivery with safe deferrals |
| 786 | Search | 41 — Implementation priorities | Incremental P0–P3 delivery with safe deferrals |
| 787 | P3 — Advanced ecosystem | 41 — Implementation priorities | Incremental P0–P3 delivery with safe deferrals |
| 788 | Shared study resources | 41 — Implementation priorities | Incremental P0–P3 delivery with safe deferrals |
| 789 | School/class spaces | 41 — Implementation priorities | Incremental P0–P3 delivery with safe deferrals |
| 790 | Ghana-specific academic content | 41 — Implementation priorities | Incremental P0–P3 delivery with safe deferrals |
| 791 | Advanced analytics | 41 — Implementation priorities | Incremental P0–P3 delivery with safe deferrals |
| 792 | Cross-device enhancements | 41 — Implementation priorities | Incremental P0–P3 delivery with safe deferrals |
| 793 | 42. DO NOT BREAK EXISTING FUNCTIONALITY | 42 — Do not break | Focused tests, validation, checkpoints, archives |
| 794 | Before implementing each major feature: | 42 — Do not break | Focused tests, validation, checkpoints, archives |
| 795 | Inspect current implementation. | 42 — Do not break | Focused tests, validation, checkpoints, archives |
| 796 | Identify dependencies. | 42 — Do not break | Focused tests, validation, checkpoints, archives |
| 797 | Make changes incrementally. | 42 — Do not break | Focused tests, validation, checkpoints, archives |
| 798 | Test. | 42 — Do not break | Focused tests, validation, checkpoints, archives |
| 799 | Verify existing features. | 42 — Do not break | Focused tests, validation, checkpoints, archives |
| 800 | Continue. | 42 — Do not break | Focused tests, validation, checkpoints, archives |
| 801 | Do not replace functioning systems unnecessarily. | 42 — Do not break | Focused tests, validation, checkpoints, archives |
| 802 | 43. MEASURE SUCCESS | 43 — Success measures | Source-controlled guarantees plus manual device boundaries |
| 803 | After implementation, Student OS should be able to demonstrate: | 43 — Success measures | Source-controlled guarantees plus manual device boundaries |
| 804 | Planning | 43 — Success measures | Source-controlled guarantees plus manual device boundaries |
| 805 | Student can create an exam and receive a realistic study plan. | 43 — Success measures | Source-controlled guarantees plus manual device boundaries |
| 806 | Learning | 43 — Success measures | Source-controlled guarantees plus manual device boundaries |
| 807 | Student can study a topic → generate flashcards → take quiz → identify weaknesses → review again. | 43 — Success measures | Source-controlled guarantees plus manual device boundaries |
| 808 | Productivity | 43 — Success measures | Source-controlled guarantees plus manual device boundaries |
| 809 | Student can create tasks and complete them through the daily plan. | 43 — Success measures | Source-controlled guarantees plus manual device boundaries |
| 810 | Focus | 43 — Success measures | Source-controlled guarantees plus manual device boundaries |
| 811 | Student can start a study session directly from a recommendation. | 43 — Success measures | Source-controlled guarantees plus manual device boundaries |
| 812 | Intelligence | 43 — Success measures | Source-controlled guarantees plus manual device boundaries |
| 813 | Student OS can recommend the next useful academic action. | 43 — Success measures | Source-controlled guarantees plus manual device boundaries |
| 814 | Persistence | 43 — Success measures | Source-controlled guarantees plus manual device boundaries |
| 815 | Student can sign in on another device and recover their workspace. | 43 — Success measures | Source-controlled guarantees plus manual device boundaries |
| 816 | Offline | 43 — Success measures | Source-controlled guarantees plus manual device boundaries |
| 817 | Core functionality continues without internet. | 43 — Success measures | Source-controlled guarantees plus manual device boundaries |
| 818 | Security | 43 — Success measures | Source-controlled guarantees plus manual device boundaries |
| 819 | User A cannot access User B's data. | 43 — Success measures | Source-controlled guarantees plus manual device boundaries |
| 820 | Performance | 43 — Success measures | Source-controlled guarantees plus manual device boundaries |
| 821 | The application remains responsive on modest Android hardware. | 43 — Success measures | Source-controlled guarantees plus manual device boundaries |
| 822 | 44. FINAL PRODUCT PRINCIPLE | 44 — Final principle | Coherence, usefulness, reliability, intelligence, simplicity |
| 823 | Build Student OS around this sentence: | 44 — Final principle | Coherence, usefulness, reliability, intelligence, simplicity |
| 824 | "Don't just help students organize their work. Help them know what to do, learn it effectively, stay consistent, and understand their progress." | 44 — Final principle | Coherence, usefulness, reliability, intelligence, simplicity |
| 825 | The application should feel like: | 44 — Final principle | Coherence, usefulness, reliability, intelligence, simplicity |
| 826 | Planner + Learning System + Study Coach + Knowledge Base + Focus System + Academic Dashboard + Secure Cloud Workspace | 44 — Final principle | Coherence, usefulness, reliability, intelligence, simplicity |
| 827 | but all connected together as ONE system. | 44 — Final principle | Coherence, usefulness, reliability, intelligence, simplicity |
| 828 | Do not chase feature count. | 44 — Final principle | Coherence, usefulness, reliability, intelligence, simplicity |
| 829 | Prioritize: | 44 — Final principle | Coherence, usefulness, reliability, intelligence, simplicity |
| 830 | coherence → usefulness → reliability → intelligence → simplicity. | 44 — Final principle | Coherence, usefulness, reliability, intelligence, simplicity |
| 831 | FINAL INSTRUCTION TO MANUS | Final — Final instruction | Current-source inspection and incremental evidence-led work |
| 832 | Before implementing major upgrades, inspect the current Student OS codebase and compare the existing functionality against this specification. | Final — Final instruction | Current-source inspection and incremental evidence-led work |
| 833 | Create an implementa | Final — Final instruction | Current-source inspection and incremental evidence-led work |
